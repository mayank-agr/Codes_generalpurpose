"""Ewald + QEq helper class

Provides a single class QEqCalculator which accepts an ASE Atoms object and
per-atom hardness/electronegativity (or uses defaults) and can solve
equilibrium charges (direct linear solve or PCG) and compute electrostatic
energy and forces using Ewald summation (real-space + reciprocal k-sum).

This is a compact, readable implementation intended for small-to-moderate
systems and as a drop-in replacement for the notebook code.
"""
from __future__ import annotations
import math
import numpy as np
from scipy import special
from scipy import linalg
from scipy import fft
from typing import Optional, Tuple, Any

try:
    from ase import Atoms
    from ase.calculators.calculator import Calculator, all_changes
except Exception:  # pragma: no cover - ASE required for real runs
    Atoms = None
    Calculator = object
    all_changes = []


class QEqCalculator(Calculator):
    """Ewald + charge-equilibration solver (ASE Calculator).

    An ASE Calculator that performs charge equilibration using the QEq method
    with Ewald summation for electrostatic interactions. This calculator computes
    atomic charges, electrostatic energy, and forces on atoms.

    Parameters
    ----------
    atoms : ase.Atoms, optional
        ASE Atoms object describing positions and cell (periodic).
        Can also be set later using set_atoms() or during calculation.
    hardness : array-like or float, optional
        Per-atom hardness (eta). If scalar provided, broadcast to atoms.
    chi : array-like or float, optional
        Electronegativity / electronegativity-like term per atom.
    param_file : str, optional
        Path to JSON file with element-specific parameters.
    Q_total : float, optional
        Total charge to constrain the solution to (default 0.0)
    alpha : float, optional
        Ewald splitting parameter (default 0.25)
    r_cut : float, optional
        Real-space cutoff in Angstrom (default min(box)/2)
    k_max : int, optional
        Reciprocal-space maximum integer for k-vectors (default 6)
    k_coulomb : float, optional
        Coulomb constant in eV·Å/e^2 (default 14.399645478425062)
    solver : str, optional
        QEq solver method: 'linear' or 'pcg' (default 'linear')
    **kwargs
        Additional keyword arguments passed to Calculator base class.
    """
    # Declare properties that this calculator can compute
    implemented_properties = ['energy', 'forces', 'charges']

    def __init__(
        self,
        atoms: Optional[Any] = None,
        hardness: Optional[np.ndarray] = None,
        chi: Optional[np.ndarray] = None,
        param_file: Optional[str] = None,
        Q_total: float = 0.0,
        alpha: float = 0.25,
        r_cut: Optional[float] = None,
        k_max: int = 6,
        k_coulomb: float = 14.399645478425062,
        solver: str = 'linear',
        **kwargs
    ) -> None:
        # Initialize the Calculator base class
        super().__init__(**kwargs)
        
        if Atoms is None:
            raise RuntimeError("ASE is required: install with `pip install ase`")
        
        # Store QEq-specific parameters
        self.k_coulomb = float(k_coulomb)
        self.alpha = float(alpha)
        self.k_max = int(k_max)
        self.Q_total = float(Q_total)
        self.solver = solver
        self._r_cut = float(r_cut) if r_cut is not None else None
        self._hardness = hardness
        self._chi = chi
        self._param_file = param_file
        
        # element-based defaults for hardness (eta) and electronegativity (chi)
        # Values are taken from an optional parameter file if provided; otherwise
        # we fall back to built-in example defaults. The param_file may be a
        # path to a JSON file mapping element symbols to {"chi":..., "eta":...}.
        self.element_defaults = {
            'H': {'chi': 4.53, 'eta': 13.89},
            'C': {'chi': 5.34, 'eta': 10.13},
            'N': {'chi': 6.90, 'eta': 11.76},
            'O': {'chi': 8.74, 'eta': 13.36},
        }

        # try to load overrides from a param file if provided or present in repo
        loaded = {}
        if self._param_file is not None:
            try:
                import json, pathlib
                p = pathlib.Path(self._param_file)
                if p.exists():
                    loaded = json.loads(p.read_text())
            except Exception:
                loaded = {}
        else:
            # search likely locations: same dir as module, or cwd
            try:
                import json, pathlib
                module_dir = pathlib.Path(__file__).parent
                for candidate in [module_dir / 'qeq_params.json', pathlib.Path('qeq_params.json')]:
                    if candidate.exists():
                        loaded = json.loads(candidate.read_text())
                        break
            except Exception:
                loaded = {}

        # merge loaded values into defaults (loaded overrides)
        for ksym, v in (loaded.items() if isinstance(loaded, dict) else []):
            try:
                if 'chi' in v or 'eta' in v:
                    self.element_defaults[ksym] = {
                        'chi': float(v.get('chi', self.element_defaults.get(ksym, {}).get('chi', 0.0))),
                        'eta': float(v.get('eta', self.element_defaults.get(ksym, {}).get('eta', 10.0)))
                    }
            except Exception:
                pass
        
        # Initialize atoms if provided
        if atoms is not None:
            self.set_atoms(atoms)

    def set_atoms(self, atoms: Any) -> None:
        """Set the atoms object and initialize system-dependent parameters."""
        self.atoms = atoms
        self.n = len(atoms)
        self.positions = atoms.get_positions()
        self.cell = np.asarray(atoms.get_cell().array if hasattr(atoms.get_cell(), 'array') else atoms.get_cell())
        # box lengths (assume orthorhombic for simplicity)
        self.box = np.array([np.linalg.norm(self.cell[i]) for i in range(3)])
        self.r_cut = self._r_cut if self._r_cut is not None else min(self.box) * 0.5

        symbols = list(self.atoms.get_chemical_symbols())

        # hardness
        if self._hardness is None:
            h_arr = np.empty(self.n, dtype=float)
            for i, s in enumerate(symbols):
                h_arr[i] = self.element_defaults.get(s, {}).get('eta', 10.0)
            self.hardness = h_arr
        else:
            h = np.asarray(self._hardness, dtype=float)
            if h.size == 1:
                h = np.ones(self.n) * float(h)
            self.hardness = h.copy()

        # chi (electronegativity)
        if self._chi is None:
            c_arr = np.empty(self.n, dtype=float)
            for i, s in enumerate(symbols):
                c_arr[i] = self.element_defaults.get(s, {}).get('chi', 0.0)
            self.chi = c_arr
        else:
            c = np.asarray(self._chi, dtype=float)
            if c.size == 1:
                c = np.ones(self.n) * float(c)
            self.chi = c.copy()
        
        # initialize charges
        self.charges = np.ones(self.n, dtype=float) * (self.Q_total / max(1, self.n))

    def calculate(self, atoms: Optional[Any] = None, properties: list = ['energy', 'forces', 'charges'], 
                  system_changes: list = all_changes) -> None:
        """Calculate properties using the QEq method.
        
        This is the main method called by ASE to compute properties.
        
        Parameters
        ----------
        atoms : ase.Atoms, optional
            Atoms object to calculate properties for. If None, uses self.atoms.
        properties : list, optional
            List of properties to calculate (default: energy, forces, charges)
        system_changes : list, optional
            List of changes since last calculation
        """
        # Call the base class calculate method to handle standard setup
        if atoms is not None:
            self.set_atoms(atoms)
        
        Calculator.calculate(self, atoms, properties, system_changes)
        
        # Update positions and cell if atoms changed
        if atoms is not None or 'positions' in system_changes or 'cell' in system_changes:
            self.positions = self.atoms.get_positions()
            self.cell = np.asarray(self.atoms.get_cell().array if hasattr(self.atoms.get_cell(), 'array') else self.atoms.get_cell())
            self.box = np.array([np.linalg.norm(self.cell[i]) for i in range(3)])
            if self._r_cut is None:
                self.r_cut = min(self.box) * 0.5
        
        # Solve for equilibrium charges
        if self.solver == 'pcg':
            q, info = self.solve_qeq_pcg()
        else:
            q = self.solve_qeq_linear()
        
        # Compute energy and forces
        energy, forces = self.total_energy_and_forces(q)
        
        # Store results in the results dictionary
        self.results['energy'] = energy
        self.results['forces'] = forces
        self.results['charges'] = q

    def get_potential_energy(self, atoms: Optional[Any] = None, force_consistent: bool = False) -> float:
        """Return the potential energy."""
        if atoms is not None or 'energy' not in self.results:
            self.calculate(atoms)
        return self.results['energy']
    
    def get_forces(self, atoms: Optional[Any] = None) -> np.ndarray:
        """Return the forces."""
        if atoms is not None or 'forces' not in self.results:
            self.calculate(atoms)
        return self.results['forces']
    
    def get_charges(self, atoms: Optional[Any] = None) -> np.ndarray:
        """Return the atomic charges."""
        if atoms is not None or 'charges' not in self.results:
            self.calculate(atoms)
        return self.results['charges']

    # ------------------------ Utilities ------------------------
    def _box_lengths(self) -> Tuple[float, float, float]:
        return tuple(self.box.tolist())

    def _mic_vector(self, i: int, j: int) -> np.ndarray:
        """Return minimum-image vector from i to j using ASE's helper where available."""
        try:
            return self.atoms.get_distance(i, j, vector=True, mic=True)
        except Exception:
            # fallback simple MIC assuming orthorhombic box
            diff = self.positions[j] - self.positions[i]
            Lx, Ly, Lz = self._box_lengths()
            diff -= np.array([Lx, Ly, Lz]) * np.round(diff / np.array([Lx, Ly, Lz]))
            return diff

    # ------------------------ Ewald kernels ------------------------
    def real_space_energy_and_forces(self, charges: np.ndarray) -> Tuple[float, np.ndarray]:
        """Compute real-space (short-range) electrostatic energy and forces.

        Uses erfc(alpha r)/r damping.
        """
        N = self.n
        energy = 0.0
        forces = np.zeros((N, 3), dtype=float)
        alpha = self.alpha
        k = self.k_coulomb
        rcut2 = self.r_cut * self.r_cut
        for i in range(N):
            qi = charges[i]
            for j in range(i + 1, N):
                qj = charges[j]
                rij_vec = self._mic_vector(i, j)
                r2 = np.dot(rij_vec, rij_vec)
                if r2 < 1e-14:
                    continue
                if r2 > rcut2:
                    continue
                r = math.sqrt(r2)
                erfc_term = special.erfc(alpha * r)
                e_pair = k * qi * qj * erfc_term / r
                energy += e_pair
                # force magnitude: -dU/dr
                d_erfc = -2.0 * alpha / math.sqrt(math.pi) * math.exp(- (alpha * r) ** 2)
                dUdr = k * qi * qj * (d_erfc / r - erfc_term / (r * r))
                fij = dUdr * (rij_vec / r)
                forces[i] += fij
                forces[j] -= fij
        return energy, forces

    def reciprocal_energy_and_forces(self, charges: np.ndarray) -> Tuple[float, np.ndarray]:
        """Compute reciprocal-space Ewald sums via direct k-vector summation.

        This is simple and robust for small systems. k_max sets the integer
        range [-k_max, k_max] for each component (excluding 0 vector).
        """
        N = self.n
        k_const = self.k_coulomb
        alpha = self.alpha
        Lx, Ly, Lz = self._box_lengths()
        V = Lx * Ly * Lz
        positions = self.positions
        charge_arr = np.asarray(charges, dtype=float)
        energy = 0.0
        forces = np.zeros((N, 3), dtype=float)
        # generate k vectors
        k_max = self.k_max
        two_pi = 2.0 * math.pi
        for nx in range(-k_max, k_max + 1):
            for ny in range(-k_max, k_max + 1):
                for nz in range(-k_max, k_max + 1):
                    if nx == 0 and ny == 0 and nz == 0:
                        continue
                    kx = two_pi * nx / Lx
                    ky = two_pi * ny / Ly
                    kz = two_pi * nz / Lz
                    k2 = kx * kx + ky * ky + kz * kz
                    if k2 == 0:
                        continue
                    exp_factor = math.exp(-k2 / (4.0 * alpha * alpha))
                    coef = (4.0 * math.pi / V) * exp_factor / k2
                    # structure factor S(k)
                    phase = np.exp(-1j * (kx * positions[:, 0] + ky * positions[:, 1] + kz * positions[:, 2]))
                    Sk = np.dot(charge_arr, phase)
                    # energy contribution
                    energy += 0.5 * k_const * coef * (Sk * np.conj(Sk)).real
                    # forces: F_i = q_i * Re[ i * k * phi_k e^{i k r_i} ] with phi_k = k_const * coef * rho_k
                    phi_k = k_const * coef * Sk
                    # field at particle i: E_i = i * sum_k k * phi_k * e^{i k r_i}
                    # we compute contribution and multiply by q_i to get force
                    # compute vector k
                    kvec = np.array([kx, ky, kz], dtype=float)
                    # accumulate per-particle complex exponential
                    exp_i = phase  # size N
                    # field contribution (complex)
                    E_complex = 1j * phi_k * (exp_i[:, None] * kvec[None, :])
                    # take real part
                    E_real = E_complex.real
                    # forces: F = q * (-E)
                    forces -= (charge_arr[:, None] * E_real)
        return energy, forces

    def self_energy(self, charges: np.ndarray) -> float:
        # self term from Ewald
        val = -self.k_coulomb * (self.alpha * 2.0 / math.sqrt(math.pi)) * 0.5 * np.sum(charges * charges)
        return val

    def total_energy_and_forces(self, charges: Optional[np.ndarray] = None) -> Tuple[float, np.ndarray]:
        """Compute total electrostatic energy and forces for given charges.

        If charges is None, use self.charges.
        Returns (energy, forces) with energy in eV and forces in eV/Å.
        """
        if charges is None:
            charges = self.charges
        charges = np.asarray(charges, dtype=float)
        E_real, F_real = self.real_space_energy_and_forces(charges)
        E_rec, F_rec = self.reciprocal_energy_and_forces(charges)
        E_self = self.self_energy(charges)
        E_total = E_real + E_rec + E_self
        F_total = F_real + F_rec
        print(f"  [Debug] E_real: {E_real:.6f}, E_rec: {E_rec:.6f}, E_self: {E_self:.6f}, E_total: {E_total:.6f}")
        return float(E_total), F_total

    # ------------------------ QEq solvers ------------------------
    def build_interaction_matrix(self) -> np.ndarray:
        """Build full A matrix (N x N) where A_ij = k_coulomb * erfc(alpha r)/r for i!=j and diagonal includes hardness + self-term."""
        N = self.n
        A = np.zeros((N, N), dtype=float)
        alpha = self.alpha
        k = self.k_coulomb
        for i in range(N):
            for j in range(i + 1, N):
                rij_vec = self._mic_vector(i, j)
                r = np.linalg.norm(rij_vec)
                if r < 1e-12:
                    val = 0.0
                else:
                    val = k * special.erfc(alpha * r) / r
                A[i, j] = val
                A[j, i] = val
        # diagonal: add hardness and self-term (-2 alpha / sqrt(pi) * k)
        diag_self = -k * (2.0 * alpha / math.sqrt(math.pi))
        for i in range(N):
            A[i, i] = self.hardness[i] + diag_self
        return A

    def solve_qeq_linear(self, Q_total: Optional[float] = None) -> np.ndarray:
        """Solve QEq by assembling the augmented linear system and solving directly."""
        print('  [Debug] Solving QEq linear system...')
        if Q_total is None:
            Q_total = self.Q_total
        A = self.build_interaction_matrix()
        N = self.n
        # augmented system [[A, 1],[1^T, 0]] [q, lambda] = [-chi, Q_total]
        M = np.zeros((N + 1, N + 1), dtype=float)
        M[:N, :N] = A
        M[:N, N] = 1.0
        M[N, :N] = 1.0
        rhs = np.zeros(N + 1, dtype=float)
        rhs[:N] = -self.chi
        rhs[N] = Q_total
        sol = linalg.solve(M, rhs, assume_a='sym')
        q = sol[:N]
        self.charges = q.copy()
        return q

    def A_dot_x(self, x: np.ndarray) -> np.ndarray:
        """Matrix-free apply of A to vector x: short-range real-space + hardness + self-term. (No reciprocal contribution included in A here.)"""
        # For simplicity include only the erfc(real) short-range kernel and hardness/self-term
        N = self.n
        y = np.zeros(N, dtype=float)
        alpha = self.alpha
        k = self.k_coulomb
        rcut2 = self.r_cut * self.r_cut
        for i in range(N):
            s = 0.0
            for j in range(N):
                if i == j:
                    continue
                rij_vec = self._mic_vector(i, j)
                r2 = np.dot(rij_vec, rij_vec)
                if r2 < 1e-14 or r2 > rcut2:
                    continue
                r = math.sqrt(r2)
                s += k * special.erfc(alpha * r) / r * x[j]
            # add diagonal
            s += (self.hardness[i] - k * (2.0 * alpha / math.sqrt(math.pi))) * x[i]
            y[i] = s
        return y

    def solve_qeq_pcg(self, Q_total: Optional[float] = None, tol: float = 1e-8, maxiter: int = 1000, precond: bool = True) -> Tuple[np.ndarray, dict]:
        """Projected Conjugate Gradient solve of A q = -chi with charge-sum constraint.
        
        Uses preconditioned conjugate gradient with improved numerical stability and
        explicit projection to maintain the total charge constraint. The solver
        uses the matrix-free A_dot_x operator and returns (charges, info).
        
        Parameters
        ----------
        Q_total : float, optional
            Total system charge (default: self.Q_total)
        tol : float
            Convergence tolerance for residual norm
        maxiter : int
            Maximum number of iterations
        precond : bool
            Whether to use diagonal preconditioning
        
        Returns
        -------
        charges : ndarray
            Optimized atomic charges
        info : dict
            Convergence information including iterations and final residual
        """
        print('  [Debug] Solving QEq PCG system...')
        if Q_total is None:
            Q_total = self.Q_total
        N = self.n
        
        # initial guess preserving total charge
        x = self.charges.copy()
        b = -self.chi
        
        # build preconditioner
        diag_self = -self.k_coulomb * (2.0 * self.alpha / math.sqrt(math.pi))
        if precond:
            M_inv = 1.0 / np.where(
                np.abs(self.hardness + diag_self) > 1e-12,
                self.hardness + diag_self,
                1e-12
            )
        else:
            M_inv = np.ones(N)
            
        # initial residual
        r = b - self.A_dot_x(x)
        r -= np.mean(r)  # project to zero-sum space
        
        # initial direction
        z = M_inv * r
        p = z.copy()
        p -= np.mean(p)  # ensure search direction preserves total charge
        
        rz = np.dot(r, z)
        norm_r = np.linalg.norm(r)
        
        if norm_r < tol:
            self.charges = x
            return x, {'converged': True, 'iters': 0, 'residual': norm_r}
            
        # PCG iteration
        for it in range(maxiter):
            Ap = self.A_dot_x(p)
            Ap -= np.mean(Ap)  # project operator output
            
            # compute step size (handle near-zero denominators)
            pAp = np.dot(p, Ap)
            if abs(pAp) < 1e-14:
                break
            alpha = rz / pAp
            
            # update solution and residual
            dx = alpha * p
            if np.linalg.norm(dx) > 1e6:  # prevent huge steps
                break
            x += dx
            r -= alpha * Ap
            r -= np.mean(r)  # maintain projection
            
            # apply preconditioner
            z = M_inv * r
            rz_new = np.dot(r, z)
            norm_r = np.linalg.norm(r)
            
            if norm_r < tol:
                self.charges = x
                return x, {'converged': True, 'iters': it+1, 'residual': norm_r}
                
            # compute new direction
            beta = rz_new / rz
            if not np.isfinite(beta) or abs(beta) > 1e6:
                break
                
            p = z + beta * p
            p -= np.mean(p)  # ensure new direction preserves charge
            rz = rz_new
            
        self.charges = x
        return x, {'converged': False, 'iters': it+1, 'residual': norm_r}


if __name__ == "__main__":
    # Example usage as an ASE Calculator
    from ase.io import read
    from ase.build import molecule
    
    # Example 1: Using with POSCAR file
    print('=== Example 1: POSCAR file solver: linear ===')
    atoms = read('POSCAR')
    calc = QEqCalculator(solver='linear')
    atoms.calc = calc
    
    # Get properties through standard ASE interface
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    charges = calc.get_charges()
    
    print('Energy (eV):', energy)
    print('Charges:', charges)
    print('Forces (eV/Å):\n', forces)

    # Example 2: Using with POSCAR file
    print('=== Example 2: POSCAR file solver: pcg ===')
    atoms = read('POSCAR')
    calc = QEqCalculator(solver='pcg')
    atoms.calc = calc
    
    # Get properties through standard ASE interface
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    charges = calc.get_charges()
    
    print('Energy (eV):', energy)
    print('Charges:', charges)
    print('Forces (eV/Å):\n', forces)

    # Example 3: Using with POSCAR file
    print('=== Example 3: POSCAR_CO2 file solver: linear ===')
    atoms = read('POSCAR_CO2')
    calc = QEqCalculator(solver='linear')
    atoms.calc = calc
    
    # Get properties through standard ASE interface
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    charges = calc.get_charges()
    
    print('Energy (eV):', energy)
    print('Charges:', charges)
    print('Forces (eV/Å):\n', forces)

    # Example 4: Using with POSCAR_CO2 file
    print('=== Example 4: POSCAR_CO2 file solver: pcg ===')
    atoms = read('POSCAR_CO2')
    calc = QEqCalculator(solver='pcg')
    atoms.calc = calc
    
    # Get properties through standard ASE interface
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    charges = calc.get_charges()
    
    print('Energy (eV):', energy)
    print('Charges:', charges)
    print('Forces (eV/Å):\n', forces)
