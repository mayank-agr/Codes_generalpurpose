"""
Test charge signs for water and CO2 molecules.
"""

from ase.build import molecule
from ase.io import read
from QEqCalculator import QEqCalculator
import os

print("=" * 70)
print("Charge Sign Verification Test")
print("=" * 70)

# Test 1: Water molecule
print("\n1. Water (H2O)")
print("-" * 70)
atoms_h2o = molecule('H2O')
atoms_h2o.center(vacuum=5.0)
atoms_h2o.set_pbc(True)

calc = QEqCalculator(method='ewald')
atoms_h2o.calc = calc
energy = atoms_h2o.get_potential_energy()
charges = calc.get_charges()

print(f"Symbols: {atoms_h2o.get_chemical_symbols()}")
print(f"Charges: {charges}")
print(f"Expected: O should be negative, H should be positive")
print(f"Result: O = {charges[0]:+.4f} e, H = {charges[1]:+.4f} e, H = {charges[2]:+.4f} e")

if charges[0] < 0 and charges[1] > 0 and charges[2] > 0:
    print("✓ PASS: Correct charge signs for H2O")
else:
    print("✗ FAIL: Incorrect charge signs for H2O")

# Test 2: CO2 molecule
print("\n2. Carbon Dioxide (CO2)")
print("-" * 70)
atoms_co2 = molecule('CO2')
atoms_co2.center(vacuum=5.0)
atoms_co2.set_pbc(True)

calc = QEqCalculator(method='ewald')
atoms_co2.calc = calc
energy = atoms_co2.get_potential_energy()
charges = calc.get_charges()

print(f"Symbols: {atoms_co2.get_chemical_symbols()}")
print(f"Charges: {charges}")
print(f"Expected: C should be positive, O should be negative")

# Identify C and O atoms
symbols = atoms_co2.get_chemical_symbols()
c_idx = symbols.index('C')
o_indices = [i for i, s in enumerate(symbols) if s == 'O']

print(f"Result: C = {charges[c_idx]:+.4f} e, O = {charges[o_indices[0]]:+.4f} e, O = {charges[o_indices[1]]:+.4f} e")

if charges[c_idx] > 0 and all(charges[i] < 0 for i in o_indices):
    print("✓ PASS: Correct charge signs for CO2")
else:
    print("✗ FAIL: Incorrect charge signs for CO2")

# Test 3: Load from POSCAR if available
if os.path.exists('POSCAR'):
    print("\n3. From POSCAR file")
    print("-" * 70)
    atoms_poscar = read('POSCAR')
    
    calc = QEqCalculator(method='ewald')
    atoms_poscar.calc = calc
    energy = atoms_poscar.get_potential_energy()
    charges = calc.get_charges()
    
    print(f"Symbols: {atoms_poscar.get_chemical_symbols()}")
    print(f"Charges: {charges}")
    print(f"Total charge: {charges.sum():.6e}")

# Test 4: Ammonia (NH3)
print("\n4. Ammonia (NH3)")
print("-" * 70)
atoms_nh3 = molecule('NH3')
atoms_nh3.center(vacuum=5.0)
atoms_nh3.set_pbc(True)

calc = QEqCalculator(method='ewald')
atoms_nh3.calc = calc
energy = atoms_nh3.get_potential_energy()
charges = calc.get_charges()

print(f"Symbols: {atoms_nh3.get_chemical_symbols()}")
print(f"Charges: {charges}")
print(f"Expected: N should be negative, H should be positive")

symbols = atoms_nh3.get_chemical_symbols()
n_idx = symbols.index('N')
h_indices = [i for i, s in enumerate(symbols) if s == 'H']

print(f"Result: N = {charges[n_idx]:+.4f} e, H = {charges[h_indices[0]]:+.4f} e")

if charges[n_idx] < 0 and all(charges[i] > 0 for i in h_indices):
    print("✓ PASS: Correct charge signs for NH3")
else:
    print("✗ FAIL: Incorrect charge signs for NH3")

print("\n" + "=" * 70)
print("Summary")
print("=" * 70)
print("The charge signs now follow expected electronegativity trends:")
print("  - More electronegative atoms (O, N) are negative")
print("  - Less electronegative atoms (H, C in CO2) are positive")
print("=" * 70 + "\n")
