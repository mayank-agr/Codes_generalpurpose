"""
Test script for QEqCalculator ASE integration.

This script demonstrates how to use QEqCalculator as a standard ASE calculator.
"""

from ase.build import molecule
from ase import Atoms
import numpy as np
import sys
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

from QEqCalculator import QEqCalculator


def test_water_molecule():
    """Test QEqCalculator with a water molecule."""
    print("=" * 60)
    print("Test 1: Water molecule with QEq calculator")
    print("=" * 60)
    
    # Create a water molecule
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    # Create and attach the calculator
    calc = QEqCalculator(solver='linear', Q_total=0.0)
    atoms.calc = calc
    
    # Get properties using standard ASE interface
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    charges = calc.get_charges()
    
    print(f"\nEnergy: {energy:.6f} eV")
    print(f"Total charge: {charges.sum():.6f}")
    print(f"\nAtomic charges:")
    for i, (symbol, charge) in enumerate(zip(atoms.get_chemical_symbols(), charges)):
        print(f"  Atom {i} ({symbol}): {charge:+.6f}")
    
    print(f"\nForces (eV/Å):")
    for i, force in enumerate(forces):
        print(f"  Atom {i}: [{force[0]:+.6f}, {force[1]:+.6f}, {force[2]:+.6f}]")
    
    return atoms, calc


def test_pcg_solver():
    """Test QEqCalculator with PCG solver."""
    print("\n" + "=" * 60)
    print("Test 2: Water molecule with PCG solver")
    print("=" * 60)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    # Use PCG solver
    calc = QEqCalculator(solver='pcg', Q_total=0.0)
    atoms.calc = calc
    
    energy = atoms.get_potential_energy()
    charges = calc.get_charges()
    
    print(f"\nEnergy: {energy:.6f} eV")
    print(f"Total charge: {charges.sum():.6f}")
    print(f"\nAtomic charges:")
    for i, (symbol, charge) in enumerate(zip(atoms.get_chemical_symbols(), charges)):
        print(f"  Atom {i} ({symbol}): {charge:+.6f}")


def test_custom_parameters():
    """Test QEqCalculator with custom hardness and chi values."""
    print("\n" + "=" * 60)
    print("Test 3: Custom parameters")
    print("=" * 60)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    # Custom parameters for H and O
    # Order: O, H, H
    custom_chi = np.array([8.5, 4.0, 4.0])
    custom_hardness = np.array([14.0, 12.0, 12.0])
    
    calc = QEqCalculator(
        chi=custom_chi,
        hardness=custom_hardness,
        Q_total=0.0,
        solver='linear'
    )
    atoms.calc = calc
    
    energy = atoms.get_potential_energy()
    charges = calc.get_charges()
    
    print(f"\nEnergy: {energy:.6f} eV")
    print(f"Total charge: {charges.sum():.6f}")
    print(f"\nAtomic charges with custom parameters:")
    for i, (symbol, charge) in enumerate(zip(atoms.get_chemical_symbols(), charges)):
        print(f"  Atom {i} ({symbol}): {charge:+.6f}")


def test_methane():
    """Test with methane molecule."""
    print("\n" + "=" * 60)
    print("Test 4: Methane (CH4) molecule")
    print("=" * 60)
    
    atoms = molecule('CH4')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    calc = QEqCalculator(solver='linear')
    atoms.calc = calc
    
    energy = atoms.get_potential_energy()
    charges = calc.get_charges()
    
    print(f"\nEnergy: {energy:.6f} eV")
    print(f"Total charge: {charges.sum():.6f}")
    print(f"\nAtomic charges:")
    for i, (symbol, charge) in enumerate(zip(atoms.get_chemical_symbols(), charges)):
        print(f"  Atom {i} ({symbol}): {charge:+.6f}")


def test_charged_system():
    """Test with a charged system."""
    print("\n" + "=" * 60)
    print("Test 5: Charged water molecule (Q = +1)")
    print("=" * 60)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    # Create calculator with total charge +1
    calc = QEqCalculator(solver='linear', Q_total=1.0)
    atoms.calc = calc
    
    energy = atoms.get_potential_energy()
    charges = calc.get_charges()
    
    print(f"\nEnergy: {energy:.6f} eV")
    print(f"Total charge: {charges.sum():.6f}")
    print(f"\nAtomic charges:")
    for i, (symbol, charge) in enumerate(zip(atoms.get_chemical_symbols(), charges)):
        print(f"  Atom {i} ({symbol}): {charge:+.6f}")


if __name__ == "__main__":
    print("\nQEqCalculator ASE Integration Tests\n")
    
    try:
        test_water_molecule()
        test_pcg_solver()
        test_custom_parameters()
        test_methane()
        test_charged_system()
        
        print("\n" + "=" * 60)
        print("All tests completed successfully!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ Error during testing: {e}")
        import traceback
        traceback.print_exc()
