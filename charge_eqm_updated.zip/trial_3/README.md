# QEqCalculator - ASE Calculator Implementation

This is a charge equilibration (QEq) calculator implemented as an ASE (Atomic Simulation Environment) calculator. It uses the Ewald summation method for electrostatic interactions.

## Features

- **ASE Calculator Interface**: Full integration with ASE's calculator framework
- **QEq Method**: Charge equilibration using electronegativity equalization
- **Ewald Summation**: Accurate treatment of long-range electrostatics in periodic systems
- **Multiple Solvers**: Direct linear solver and Preconditioned Conjugate Gradient (PCG)
- **Element Defaults**: Built-in parameters for common elements (H, C, N, O, S, P, Cl, Na, K, Fe)
- **Custom Parameters**: Support for custom hardness and electronegativity values
- **Parameter Files**: Load parameters from JSON files

## Installation

Requires ASE and standard scientific Python packages:

```bash
pip install ase numpy scipy
```

## Usage

### Basic Usage

```python
from ase.build import molecule
from QEQCalculator import QEqCalculator

# Create a molecule
atoms = molecule('H2O')
atoms.center(vacuum=5.0)
atoms.set_pbc(True)

# Create and attach calculator
calc = QEqCalculator()
atoms.calc = calc

# Get properties using standard ASE interface
energy = atoms.get_potential_energy()
forces = atoms.get_forces()
charges = calc.get_charges()
```

### Using PCG Solver

```python
calc = QEqCalculator(solver='pcg')
atoms.calc = calc
energy = atoms.get_potential_energy()
```

### Custom Parameters

```python
import numpy as np

# Specify custom chi and hardness for each atom
custom_chi = np.array([8.5, 4.0, 4.0])  # O, H, H
custom_hardness = np.array([14.0, 12.0, 12.0])

calc = QEqCalculator(chi=custom_chi, hardness=custom_hardness)
atoms.calc = calc
```

### Charged Systems

```python
# System with total charge +1
calc = QEqCalculator(Q_total=1.0)
atoms.calc = calc
energy = atoms.get_potential_energy()
```

### Using Parameter Files

Create a JSON file `qeq_params.json`:

```json
{
  "H": {"chi": 4.5, "eta": 13.0},
  "C": {"chi": 6.0, "eta": 10.0},
  "O": {"chi": 8.0, "eta": 13.0}
}
```

Then use it:

```python
calc = QEqCalculator(param_file='qeq_params.json')
```

## Constructor Parameters

- `atoms` (Atoms, optional): ASE Atoms object
- `hardness` (array or float, optional): Per-atom hardness (η) in eV
- `chi` (array or float, optional): Per-atom electronegativity in eV
- `param_file` (str, optional): Path to JSON parameter file
- `Q_total` (float, default=0.0): Total system charge
- `alpha` (float, default=0.25): Ewald splitting parameter in Å⁻¹
- `r_cut` (float, optional): Real-space cutoff in Å (default: min(box)/2)
- `k_max` (int, default=6): Maximum k-vector index for reciprocal space
- `k_coulomb` (float, default=14.399645): Coulomb constant in eV·Å/e²
- `solver` (str, default='linear'): Solver method ('linear' or 'pcg')

## Properties Computed

The calculator implements these ASE properties:

- `energy`: Total electrostatic energy (eV)
- `forces`: Forces on atoms (eV/Å)
- `charges`: Atomic partial charges (e)

Access them via standard ASE methods:

```python
energy = atoms.get_potential_energy()
forces = atoms.get_forces()
charges = calc.get_charges()  # Custom method for charges
```

## Methods

### Standard ASE Methods

- `calculate(atoms, properties, system_changes)`: Main calculation method
- `get_potential_energy(atoms)`: Return potential energy
- `get_forces(atoms)`: Return forces

### Custom Methods

- `get_charges(atoms)`: Return atomic charges
- `set_atoms(atoms)`: Set/update the atoms object
- `solve_qeq_linear(Q_total)`: Solve QEq using direct linear solver
- `solve_qeq_pcg(Q_total, tol, maxiter, precond)`: Solve QEq using PCG
- `total_energy_and_forces(charges)`: Compute energy and forces for given charges

## Testing

Run the test script:

```bash
python test_qeq_calculator.py
```

This will run several tests demonstrating different features of the calculator.

## Implementation Details

### Ewald Summation

The calculator uses Ewald summation to compute electrostatic interactions:

- **Real-space term**: Short-range interactions using erfc(αr)/r
- **Reciprocal-space term**: Long-range interactions via k-space sum
- **Self-term**: Self-interaction correction

### QEq Method

The charge equilibration is formulated as:

```
A q = -χ
subject to: Σq = Q_total
```

Where:
- A is the interaction matrix (includes Coulomb interactions + hardness)
- q are the atomic charges
- χ are the electronegativities
- Q_total is the total system charge

Two solvers are available:

1. **Linear solver**: Direct solution via augmented system
2. **PCG solver**: Iterative preconditioned conjugate gradient

## Element Defaults

Built-in parameters (χ in eV, η in eV):

| Element | χ (chi) | η (eta) |
|---------|---------|---------|
| H       | 4.5     | 13.0    |
| C       | 6.0     | 10.0    |
| N       | 7.0     | 11.0    |
| O       | 8.0     | 13.0    |
| S       | 6.5     | 9.0     |
| P       | 5.5     | 9.5     |
| Cl      | 6.0     | 8.5     |
| Na      | 2.8     | 5.0     |
| K       | 2.3     | 4.5     |
| Fe      | 5.0     | 8.0     |

## Notes

- The implementation assumes orthorhombic cells for simplicity
- Periodic boundary conditions are required
- The calculator is designed for small to moderate systems
- For large systems, the PCG solver may be more efficient

## References

The QEq method and Ewald summation are based on standard techniques in computational chemistry. For more details, see:

- Rappé, A. K., & Goddard, W. A. (1991). Charge equilibration for molecular dynamics simulations. *The Journal of Physical Chemistry*, 95(8), 3358-3363.
- Ewald, P. P. (1921). Die Berechnung optischer und elektrostatischer Gitterpotentiale. *Annalen der Physik*, 369(3), 253-287.
