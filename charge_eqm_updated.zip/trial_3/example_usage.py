"""
Quick usage example for QEqCalculator ASE integration.

This demonstrates the simplest way to use the calculator.
"""

from ase.io import read
from QEqCalculator import QEqCalculator

# Load water molecule from POSCAR file
print("Loading H2O molecule from POSCAR...")
atoms = read('POSCAR')

for dataset in ['GMP', 'CCSD_Smit', 'EXP']:
    print(f"\nUsing chi/eta dataset: {dataset}")
    for method in ['direct', 'ewald']:
        for solver in ['linear', 'pcg']:
            # Create the QEq calculator
            print(f"Method={method} and solver={solver}...")
            calc = QEqCalculator(method=method, solver=solver, dataset_chi_eta=dataset)

            # Attach calculator to atoms
            atoms.calc = calc

            # Calculate properties using standard ASE interface
            print("\nCalculating properties...")
            energy = atoms.get_potential_energy()
            forces = atoms.get_forces()
            charges = calc.get_charges()

            # Print results
            print(f"\n{'='*50}")
            print("Results for H2O molecule")
            print(f"{'='*50}")
            print(f"\nElectrostatic Energy: {energy:.4f} eV")
            print(f"\nAtomic Charges:")
            for i, (symbol, charge) in enumerate(zip(atoms.get_chemical_symbols(), charges)):
                print(f"  {symbol} (atom {i}): {charge:+.4f} e")

            print(f"\nForces on atoms (eV/Å):")
            for i, (symbol, force) in enumerate(zip(atoms.get_chemical_symbols(), forces)):
                print(f"  {symbol} (atom {i}): [{force[0]:+7.4f}, {force[1]:+7.4f}, {force[2]:+7.4f}]")

            print(f"\nTotal charge: {charges.sum():.6f} e")
            print(f"{'='*50}\n")
