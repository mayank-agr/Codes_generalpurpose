"""
Quick example comparing Ewald and Direct Coulomb methods.
"""

from ase.build import molecule
from ase.io import read
from QEqCalculator import QEqCalculator

# Load molecule
atoms = read('POSCAR')
atoms.set_pbc(True)

print("=" * 60)
print("Water Molecule: Ewald vs Direct Coulomb")
print("=" * 60)

# Ewald method
print("\n1. Ewald Summation Method")
print("-" * 60)
calc_ewald = QEqCalculator(method='ewald')
atoms.calc = calc_ewald
E_ewald = atoms.get_potential_energy()
q_ewald = calc_ewald.get_charges()

print(f"Energy:  {E_ewald:10.4f} eV")
print(f"Charges: O={q_ewald[0]:+.4f}, H={q_ewald[1]:+.4f}, H={q_ewald[2]:+.4f}")

# Direct Coulomb method
print("\n2. Direct Coulomb Method")
print("-" * 60)
calc_direct = QEqCalculator(method='direct')
atoms.calc = calc_direct
E_direct = atoms.get_potential_energy()
q_direct = calc_direct.get_charges()

print(f"Energy:  {E_direct:10.4f} eV")
print(f"Charges: O={q_direct[0]:+.4f}, H={q_direct[1]:+.4f}, H={q_direct[2]:+.4f}")

# Comparison
print("\n3. Comparison")
print("-" * 60)
print(f"ΔE = {abs(E_ewald - E_direct):.4f} eV")
print(f"ΔQ(max) = {max(abs(q_ewald - q_direct)):.4f} e")

print("\n" + "=" * 60)
print("Both methods use minimum image convention for distances.")
print("Differences arise from long-range interaction treatment:")
print("  - Ewald: Rigorous periodic treatment")
print("  - Direct: Simple cutoff at box boundary")
print("=" * 60 + "\n")
