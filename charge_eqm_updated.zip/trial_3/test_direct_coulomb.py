"""
Test script to compare Ewald vs Direct Coulomb methods.
"""

import numpy as np
from ase.build import molecule
from QEqCalculator import QEqCalculator


def test_method_comparison():
    """Compare Ewald and direct Coulomb methods."""
    print("=" * 70)
    print("Comparison: Ewald vs Direct Coulomb")
    print("=" * 70)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    print("\n" + "-" * 70)
    print("Method: Ewald Summation")
    print("-" * 70)
    calc_ewald = QEqCalculator(method='ewald')
    atoms.calc = calc_ewald
    E_ewald = atoms.get_potential_energy()
    F_ewald = atoms.get_forces()
    q_ewald = calc_ewald.get_charges()
    
    print(f"\nEnergy: {E_ewald:.6f} eV")
    print(f"Charges: {q_ewald}")
    print(f"Forces:\n{F_ewald}")
    
    print("\n" + "-" * 70)
    print("Method: Direct Coulomb")
    print("-" * 70)
    calc_direct = QEqCalculator(method='direct')
    atoms.calc = calc_direct
    E_direct = atoms.get_potential_energy()
    F_direct = atoms.get_forces()
    q_direct = calc_direct.get_charges()
    
    print(f"\nEnergy: {E_direct:.6f} eV")
    print(f"Charges: {q_direct}")
    print(f"Forces:\n{F_direct}")
    
    print("\n" + "=" * 70)
    print("Comparison Summary")
    print("=" * 70)
    print(f"\nEnergy difference: {abs(E_ewald - E_direct):.6f} eV")
    print(f"Max charge difference: {np.max(np.abs(q_ewald - q_direct)):.6e}")
    print(f"Max force difference: {np.max(np.abs(F_ewald - F_direct)):.6f} eV/Å")
    
    print("\nNote: Differences are expected due to different treatment of")
    print("long-range interactions (Ewald vs direct truncation at box boundary)")


def test_minimum_image():
    """Test that minimum image convention is working in direct method."""
    print("\n" + "=" * 70)
    print("Test: Minimum Image Convention (Direct Method)")
    print("=" * 70)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    calc = QEqCalculator(method='direct')
    atoms.calc = calc
    
    # Get charges first
    E1 = atoms.get_potential_energy()
    q = calc.get_charges()
    
    print(f"\nOriginal configuration:")
    print(f"Energy: {E1:.6f} eV")
    print(f"Charges: {q}")
    
    # Manually compute one interaction to verify MIC
    calc_internal = calc
    r_vec = calc_internal._mic_vector(0, 1)
    r = np.linalg.norm(r_vec)
    
    print(f"\nDistance O-H (atom 0-1) with MIC: {r:.4f} Å")
    print(f"Vector (MIC): {r_vec}")
    
    # Direct distance without MIC for comparison
    r_direct = np.linalg.norm(atoms.positions[1] - atoms.positions[0])
    print(f"Direct distance (no MIC): {r_direct:.4f} Å")
    
    if abs(r - r_direct) < 1e-6:
        print("✓ MIC gives same result (atoms within same image)")
    else:
        print("✓ MIC applied (atoms across periodic boundary)")


def test_charged_systems():
    """Test both methods with charged systems."""
    print("\n" + "=" * 70)
    print("Test: Charged Systems")
    print("=" * 70)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    for Q_total in [0.0, 1.0, -1.0]:
        print(f"\n{'Total charge:':<20} {Q_total:+.1f}")
        print("-" * 50)
        
        calc_ewald = QEqCalculator(method='ewald', Q_total=Q_total)
        atoms.calc = calc_ewald
        E_ewald = atoms.get_potential_energy()
        q_ewald = calc_ewald.get_charges()
        
        calc_direct = QEqCalculator(method='direct', Q_total=Q_total)
        atoms.calc = calc_direct
        E_direct = atoms.get_potential_energy()
        q_direct = calc_direct.get_charges()
        
        print(f"{'Method':<15} {'Energy (eV)':<15} {'Total Q':<12}")
        print(f"{'Ewald':<15} {E_ewald:<15.6f} {q_ewald.sum():+.6f}")
        print(f"{'Direct':<15} {E_direct:<15.6f} {q_direct.sum():+.6f}")


def test_force_numerical():
    """Verify forces with numerical derivatives for direct method."""
    print("\n" + "=" * 70)
    print("Test: Force Validation (Direct Method)")
    print("=" * 70)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    calc = QEqCalculator(method='direct')
    atoms.calc = calc
    
    # Get analytical forces
    E0 = atoms.get_potential_energy()
    F_analytical = atoms.get_forces()
    
    # Numerical force for first atom, x-direction
    delta = 0.0001
    atom_idx = 0
    direction = 0
    
    pos_orig = atoms.positions.copy()
    
    atoms.positions[atom_idx, direction] += delta
    atoms.calc = QEqCalculator(method='direct')
    E_plus = atoms.get_potential_energy()
    
    atoms.positions = pos_orig.copy()
    atoms.positions[atom_idx, direction] -= delta
    atoms.calc = QEqCalculator(method='direct')
    E_minus = atoms.get_potential_energy()
    
    atoms.positions = pos_orig
    
    F_numerical = -(E_plus - E_minus) / (2 * delta)
    F_ana = F_analytical[atom_idx, direction]
    
    print(f"\nAtom {atom_idx}, direction {['x', 'y', 'z'][direction]}:")
    print(f"Analytical force:  {F_ana:+.6f} eV/Å")
    print(f"Numerical force:   {F_numerical:+.6f} eV/Å")
    print(f"Difference:        {abs(F_ana - F_numerical):.6f} eV/Å")
    
    if abs(F_ana - F_numerical) / (abs(F_ana) + 1e-10) < 0.01:
        print("✓ PASS: Forces match numerical derivative")
    else:
        print("⚠ WARNING: Force mismatch")


def main():
    print("\n" + "=" * 70)
    print("Direct Coulomb Method - Testing")
    print("=" * 70)
    
    try:
        test_method_comparison()
        test_minimum_image()
        test_charged_systems()
        test_force_numerical()
        
        print("\n" + "=" * 70)
        print("All tests completed!")
        print("=" * 70 + "\n")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
