"""
Validation tests for Ewald summation implementation in QEqCalculator.

This script checks:
1. Charge neutrality and self-consistency
2. Energy convergence with k_max
3. Force calculation (numerical vs analytical)
4. Real-space cutoff dependence
5. Ewald parameter sensitivity
"""

import numpy as np
from ase.io import read
from ase.build import molecule
from QEqCalculator import QEqCalculator


def test_charge_neutrality():
    """Test 1: Charge neutrality for neutral systems."""
    print("=" * 70)
    print("Test 1: Charge Neutrality")
    print("=" * 70)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    calc = QEqCalculator(Q_total=0.0)
    atoms.calc = calc
    
    energy = atoms.get_potential_energy()
    charges = calc.get_charges()
    
    total_charge = charges.sum()
    print(f"\nTotal charge requested: 0.0")
    print(f"Total charge obtained: {total_charge:.15f}")
    print(f"Deviation: {abs(total_charge):.2e}")
    
    if abs(total_charge) < 1e-10:
        print("✓ PASS: Charge neutrality maintained")
    else:
        print("✗ FAIL: Charge not neutral")
    
    return abs(total_charge) < 1e-10


def test_energy_convergence():
    """Test 2: Energy convergence with k_max."""
    print("\n" + "=" * 70)
    print("Test 2: Reciprocal Space Convergence")
    print("=" * 70)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=6.0)
    atoms.set_pbc(True)
    
    k_max_values = [3, 4, 5, 6, 7, 8]
    energies = []
    
    print(f"\n{'k_max':<8} {'Energy (eV)':<15} {'ΔE (meV)':<12}")
    print("-" * 45)
    
    for k_max in k_max_values:
        calc = QEqCalculator(k_max=k_max, solver='linear')
        atoms.calc = calc
        energy = atoms.get_potential_energy()
        energies.append(energy)
        
        if len(energies) > 1:
            delta_E = (energies[-1] - energies[-2]) * 1000  # meV
            print(f"{k_max:<8} {energy:<15.6f} {delta_E:+.4f}")
        else:
            print(f"{k_max:<8} {energy:<15.6f} {'---':<12}")
    
    # Check convergence
    final_diff = abs(energies[-1] - energies[-2]) * 1000  # meV
    print(f"\nFinal energy difference: {final_diff:.4f} meV")
    
    if final_diff < 0.1:
        print("✓ PASS: Energy converged with k_max")
    else:
        print("⚠ WARNING: May need higher k_max for full convergence")
    
    return final_diff < 1.0


def test_force_consistency():
    """Test 3: Force consistency with numerical derivative."""
    print("\n" + "=" * 70)
    print("Test 3: Force vs Numerical Derivative")
    print("=" * 70)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    calc = QEqCalculator()
    atoms.calc = calc
    
    # Get analytical forces
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    
    # Compute numerical forces for first atom, x-direction
    delta = 0.0001  # Angstrom
    atom_idx = 0
    direction = 0
    
    pos_orig = atoms.positions.copy()
    
    # Forward step
    atoms.positions[atom_idx, direction] += delta
    atoms.calc = QEqCalculator()  # Need fresh calculator
    E_plus = atoms.get_potential_energy()
    
    # Backward step
    atoms.positions = pos_orig.copy()
    atoms.positions[atom_idx, direction] -= delta
    atoms.calc = QEqCalculator()
    E_minus = atoms.get_potential_energy()
    
    # Restore
    atoms.positions = pos_orig
    
    # Numerical force
    F_numerical = -(E_plus - E_minus) / (2 * delta)
    F_analytical = forces[atom_idx, direction]
    
    print(f"\nAtom {atom_idx}, direction {['x', 'y', 'z'][direction]}:")
    print(f"Analytical force:  {F_analytical:+.6f} eV/Å")
    print(f"Numerical force:   {F_numerical:+.6f} eV/Å")
    print(f"Difference:        {abs(F_analytical - F_numerical):.6f} eV/Å")
    print(f"Relative error:    {abs(F_analytical - F_numerical) / (abs(F_analytical) + 1e-10) * 100:.2f}%")
    
    rel_error = abs(F_analytical - F_numerical) / (abs(F_analytical) + 1e-10)
    
    if rel_error < 0.01:  # 1% relative error
        print("✓ PASS: Forces consistent with energy gradient")
    else:
        print("⚠ WARNING: Forces may have numerical issues")
    
    return rel_error < 0.05


def test_ewald_self_term():
    """Test 4: Ewald self-energy term."""
    print("\n" + "=" * 70)
    print("Test 4: Self-Energy Term")
    print("=" * 70)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    calc = QEqCalculator()
    atoms.calc = calc
    
    # Get charges
    energy = atoms.get_potential_energy()
    charges = calc.get_charges()
    
    # Compute self-energy manually
    alpha = calc.alpha
    k = calc.k_coulomb
    self_energy_manual = -k * (2.0 * alpha / np.sqrt(np.pi)) * 0.5 * np.sum(charges * charges)
    self_energy_calc = calc.self_energy(charges)
    
    print(f"\nSelf-energy (calculator): {self_energy_calc:.8f} eV")
    print(f"Self-energy (manual):     {self_energy_manual:.8f} eV")
    print(f"Difference:               {abs(self_energy_calc - self_energy_manual):.2e} eV")
    
    if abs(self_energy_calc - self_energy_manual) < 1e-10:
        print("✓ PASS: Self-energy calculated correctly")
    else:
        print("✗ FAIL: Self-energy calculation error")
    
    return abs(self_energy_calc - self_energy_manual) < 1e-10


def test_symmetry():
    """Test 5: Symmetry - identical atoms should have identical charges."""
    print("\n" + "=" * 70)
    print("Test 5: Symmetry in Charges")
    print("=" * 70)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    calc = QEqCalculator()
    atoms.calc = calc
    
    energy = atoms.get_potential_energy()
    charges = calc.get_charges()
    
    # H2O has 2 H atoms (indices 1 and 2)
    H1_charge = charges[1]
    H2_charge = charges[2]
    
    print(f"\nH atom 1 charge: {H1_charge:+.10f}")
    print(f"H atom 2 charge: {H2_charge:+.10f}")
    print(f"Difference:      {abs(H1_charge - H2_charge):.2e}")
    
    if abs(H1_charge - H2_charge) < 1e-10:
        print("✓ PASS: Symmetric atoms have identical charges")
    else:
        print("⚠ WARNING: Symmetry slightly broken (may be numerical)")
    
    return abs(H1_charge - H2_charge) < 1e-8


def test_alpha_parameter():
    """Test 6: Effect of alpha (Ewald splitting parameter)."""
    print("\n" + "=" * 70)
    print("Test 6: Ewald Alpha Parameter Dependence")
    print("=" * 70)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    alpha_values = [0.15, 0.20, 0.25, 0.30, 0.35]
    energies = []
    
    print(f"\n{'alpha':<8} {'Energy (eV)':<15} {'O charge':<12} {'H charge':<12}")
    print("-" * 55)
    
    for alpha in alpha_values:
        calc = QEqCalculator(alpha=alpha)
        atoms.calc = calc
        energy = atoms.get_potential_energy()
        charges = calc.get_charges()
        energies.append(energy)
        
        print(f"{alpha:<8.2f} {energy:<15.6f} {charges[0]:+.6f}    {charges[1]:+.6f}")
    
    # Check if energies are consistent (should be similar with optimal alpha)
    energy_std = np.std(energies)
    print(f"\nEnergy standard deviation: {energy_std:.6f} eV")
    
    # Energy should not vary too much with alpha if properly implemented
    if energy_std < 0.5:
        print("✓ PASS: Energy relatively stable across alpha values")
    else:
        print("⚠ WARNING: Large energy variation with alpha")
    
    return energy_std < 1.0


def test_reciprocal_vs_real():
    """Test 7: Balance between real and reciprocal space contributions."""
    print("\n" + "=" * 70)
    print("Test 7: Real vs Reciprocal Space Balance")
    print("=" * 70)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    calc = QEqCalculator()
    atoms.calc = calc
    
    energy = atoms.get_potential_energy()
    charges = calc.get_charges()
    
    # Get individual components
    E_real, F_real = calc.real_space_energy_and_forces(charges)
    E_rec, F_rec = calc.reciprocal_energy_and_forces(charges)
    E_self = calc.self_energy(charges)
    
    print(f"\nEnergy components:")
    print(f"  Real space:       {E_real:+10.6f} eV ({abs(E_real) / abs(energy) * 100:5.1f}%)")
    print(f"  Reciprocal space: {E_rec:+10.6f} eV ({abs(E_rec) / abs(energy) * 100:5.1f}%)")
    print(f"  Self energy:      {E_self:+10.6f} eV ({abs(E_self) / abs(energy) * 100:5.1f}%)")
    print(f"  Total:            {energy:+10.6f} eV")
    print(f"  Sum check:        {E_real + E_rec + E_self:+10.6f} eV")
    
    sum_check = abs((E_real + E_rec + E_self) - energy)
    
    if sum_check < 1e-10:
        print("✓ PASS: Energy components sum correctly")
    else:
        print("✗ FAIL: Energy components don't sum correctly")
    
    return sum_check < 1e-8


def test_solver_agreement():
    """Test 8: Linear vs PCG solver agreement."""
    print("\n" + "=" * 70)
    print("Test 8: Linear vs PCG Solver Agreement")
    print("=" * 70)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    # Linear solver
    calc_linear = QEqCalculator(solver='linear')
    atoms.calc = calc_linear
    E_linear = atoms.get_potential_energy()
    q_linear = calc_linear.get_charges()
    
    # PCG solver
    calc_pcg = QEqCalculator(solver='pcg')
    atoms.calc = calc_pcg
    E_pcg = atoms.get_potential_energy()
    q_pcg = calc_pcg.get_charges()
    
    print(f"\nLinear solver:")
    print(f"  Energy: {E_linear:.8f} eV")
    print(f"  Charges: {q_linear}")
    
    print(f"\nPCG solver:")
    print(f"  Energy: {E_pcg:.8f} eV")
    print(f"  Charges: {q_pcg}")
    
    print(f"\nDifferences:")
    print(f"  Energy: {abs(E_linear - E_pcg):.2e} eV")
    print(f"  Max charge difference: {np.max(np.abs(q_linear - q_pcg)):.2e}")
    
    energy_match = abs(E_linear - E_pcg) < 1e-6
    charge_match = np.max(np.abs(q_linear - q_pcg)) < 1e-6
    
    if energy_match and charge_match:
        print("✓ PASS: Both solvers agree")
    else:
        print("✗ FAIL: Solvers disagree")
    
    return energy_match and charge_match


def main():
    print("\n" + "=" * 70)
    print("QEqCalculator Ewald Summation Validation")
    print("=" * 70)
    
    results = []
    
    try:
        results.append(("Charge Neutrality", test_charge_neutrality()))
        results.append(("Energy Convergence", test_energy_convergence()))
        results.append(("Force Consistency", test_force_consistency()))
        results.append(("Self-Energy", test_ewald_self_term()))
        results.append(("Symmetry", test_symmetry()))
        results.append(("Alpha Parameter", test_alpha_parameter()))
        results.append(("Real vs Reciprocal", test_reciprocal_vs_real()))
        results.append(("Solver Agreement", test_solver_agreement()))
        
    except Exception as e:
        print(f"\n\n❌ Error during testing: {e}")
        import traceback
        traceback.print_exc()
        return
    
    # Summary
    print("\n" + "=" * 70)
    print("VALIDATION SUMMARY")
    print("=" * 70)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✓ PASS" if result else "✗ FAIL"
        print(f"{status}  {test_name}")
    
    print("\n" + "=" * 70)
    print(f"Overall: {passed}/{total} tests passed")
    print("=" * 70)
    
    if passed == total:
        print("\n🎉 All validation tests passed! Ewald implementation is correct.")
    else:
        print(f"\n⚠️  {total - passed} test(s) failed. Review implementation.")


if __name__ == "__main__":
    main()
