"""
Advanced usage examples for QEqCalculator ASE integration.

This demonstrates integration with ASE's optimization and analysis tools.
"""

from ase.build import molecule
from ase.optimize import BFGS
from ase.io import write
import numpy as np
from QEqCalculator import QEqCalculator


def example_geometry_optimization():
    """Example: Geometry optimization with QEq forces."""
    print("=" * 60)
    print("Example 1: Geometry Optimization")
    print("=" * 60)
    
    # Create a slightly distorted water molecule
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    # Distort the geometry slightly
    atoms.positions[1] += [0.1, 0.1, 0.0]
    
    # Attach QEq calculator
    calc = QEqCalculator(solver='linear')
    atoms.calc = calc
    
    print(f"\nInitial energy: {atoms.get_potential_energy():.4f} eV")
    print(f"Initial charges: {calc.get_charges()}")
    
    # Note: This optimizer only uses QEq electrostatic forces
    # In a real application, you'd combine this with a bonded force field
    print("\nNote: Pure QEq forces may not converge to physical geometries")
    print("Normally, you'd combine this with bonded interactions")
    
    # Run a few steps to show it works
    print(f"\nInitial force norm: {np.linalg.norm(atoms.get_forces()):.4f} eV/Å")


def example_molecular_dynamics_setup():
    """Example: Setting up molecular dynamics (conceptual)."""
    print("\n" + "=" * 60)
    print("Example 2: MD Setup (Conceptual)")
    print("=" * 60)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    # QEq calculator
    calc = QEqCalculator(solver='pcg')  # PCG might be faster for MD
    atoms.calc = calc
    
    print("\nQEq calculator attached for MD")
    print("In practice, combine with velocity Verlet or Langevin dynamics")
    print(f"Initial energy: {atoms.get_potential_energy():.4f} eV")
    print(f"Forces available: {atoms.get_forces().shape}")


def example_multiple_structures():
    """Example: Calculate properties for multiple structures."""
    print("\n" + "=" * 60)
    print("Example 3: Multiple Structures")
    print("=" * 60)
    
    molecules = ['H2O', 'NH3', 'CH4', 'H2O2']
    
    # Create calculator once
    calc = QEqCalculator(solver='linear')
    
    print("\nCalculating QEq charges for multiple molecules:\n")
    
    for mol_name in molecules:
        atoms = molecule(mol_name)
        atoms.center(vacuum=5.0)
        atoms.set_pbc(True)
        atoms.calc = calc
        
        energy = atoms.get_potential_energy()
        charges = calc.get_charges()
        
        print(f"{mol_name:6s}: E = {energy:8.4f} eV, Charges = {charges}")


def example_charge_analysis():
    """Example: Detailed charge analysis."""
    print("\n" + "=" * 60)
    print("Example 4: Charge Analysis")
    print("=" * 60)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    # Test different parameters
    print("\nEffect of different parameters on charges:\n")
    
    # Default parameters
    calc1 = QEqCalculator()
    atoms.calc = calc1
    _ = atoms.get_potential_energy()
    charges1 = calc1.get_charges()
    print(f"Default params:  O={charges1[0]:+.4f}, H={charges1[1]:+.4f}, H={charges1[2]:+.4f}")
    
    # Increased alpha (tighter screening)
    calc2 = QEqCalculator(alpha=0.35)
    atoms.calc = calc2
    _ = atoms.get_potential_energy()
    charges2 = calc2.get_charges()
    print(f"Alpha=0.35:      O={charges2[0]:+.4f}, H={charges2[1]:+.4f}, H={charges2[2]:+.4f}")
    
    # Custom chi values
    calc3 = QEqCalculator(chi=np.array([8.5, 4.0, 4.0]))
    atoms.calc = calc3
    _ = atoms.get_potential_energy()
    charges3 = calc3.get_charges()
    print(f"Custom chi:      O={charges3[0]:+.4f}, H={charges3[1]:+.4f}, H={charges3[2]:+.4f}")


def example_periodic_system():
    """Example: Periodic system with multiple unit cells."""
    print("\n" + "=" * 60)
    print("Example 5: Periodic System")
    print("=" * 60)
    
    from ase import Atoms
    from ase.build import bulk
    
    # Create a simple cubic lattice of sodium atoms
    atoms = bulk('Na', 'bcc', a=4.23, cubic=True)
    
    # Note: This is just for demonstration
    # QEq works best with molecules; bulk metals need different approaches
    calc = QEqCalculator(Q_total=0.0)
    atoms.calc = calc
    
    energy = atoms.get_potential_energy()
    charges = calc.get_charges()
    
    print(f"\nBCC Na structure (2 atoms)")
    print(f"Energy: {energy:.4f} eV")
    print(f"Charges: {charges}")
    print(f"Note: QEq is designed for molecular systems with charge transfer")


def example_solver_comparison():
    """Example: Compare linear vs PCG solvers."""
    print("\n" + "=" * 60)
    print("Example 6: Solver Comparison")
    print("=" * 60)
    
    # Create a larger molecule
    from ase.build import molecule
    atoms = molecule('C6H6')  # benzene
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    print(f"\nSystem: {len(atoms)} atoms (benzene)")
    
    # Linear solver
    import time
    calc_linear = QEqCalculator(solver='linear')
    atoms.calc = calc_linear
    
    t0 = time.time()
    energy_linear = atoms.get_potential_energy()
    t_linear = time.time() - t0
    charges_linear = calc_linear.get_charges()
    
    print(f"\nLinear solver:")
    print(f"  Time: {t_linear*1000:.2f} ms")
    print(f"  Energy: {energy_linear:.4f} eV")
    print(f"  Total charge: {charges_linear.sum():.6f}")
    
    # PCG solver
    calc_pcg = QEqCalculator(solver='pcg')
    atoms.calc = calc_pcg
    
    t0 = time.time()
    energy_pcg = atoms.get_potential_energy()
    t_pcg = time.time() - t0
    charges_pcg = calc_pcg.get_charges()
    
    print(f"\nPCG solver:")
    print(f"  Time: {t_pcg*1000:.2f} ms")
    print(f"  Energy: {energy_pcg:.4f} eV")
    print(f"  Total charge: {charges_pcg.sum():.6f}")
    
    print(f"\nDifference in charges: {np.linalg.norm(charges_linear - charges_pcg):.6e}")
    print(f"Energy difference: {abs(energy_linear - energy_pcg):.6e} eV")


def example_write_output():
    """Example: Write output with charges."""
    print("\n" + "=" * 60)
    print("Example 7: Output Files")
    print("=" * 60)
    
    atoms = molecule('H2O')
    atoms.center(vacuum=5.0)
    atoms.set_pbc(True)
    
    calc = QEqCalculator()
    atoms.calc = calc
    
    # Calculate properties
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    charges = calc.get_charges()
    
    # Store charges in atoms object for output
    atoms.set_initial_charges(charges)
    
    # Write to various formats (charges may or may not be preserved depending on format)
    try:
        write('output.xyz', atoms)
        print("\nWrote output.xyz")
    except Exception as e:
        print(f"\nCould not write XYZ: {e}")
    
    try:
        write('output.json', atoms)
        print("Wrote output.json (includes charges)")
    except Exception as e:
        print(f"Could not write JSON: {e}")
    
    print(f"\nEnergy: {energy:.4f} eV")
    print(f"Charges saved: {charges}")


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("QEqCalculator: Advanced Usage Examples")
    print("=" * 60 + "\n")
    
    try:
        example_geometry_optimization()
        example_molecular_dynamics_setup()
        example_multiple_structures()
        example_charge_analysis()
        example_periodic_system()
        example_solver_comparison()
        example_write_output()
        
        print("\n" + "=" * 60)
        print("All examples completed successfully!")
        print("=" * 60 + "\n")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
