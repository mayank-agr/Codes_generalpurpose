"""Compare charges from DIRECT, EWALD, and PME methods.

The QEq charges should be SIMILAR across methods because they all solve
the same equilibrium condition: electronegativity equalization.
The electrostatic energy will differ, but charges should be close.
"""

import numpy as np
from ase.io import read
from QEqCalculator import QEqCalculator

# Test on water molecule first (simple case)
print("="*70)
print("WATER MOLECULE TEST")
print("="*70)

from ase import Atoms

# Create water molecule
positions = np.array([
    [0.0, 0.0, 0.0],      # O
    [0.757, 0.586, 0.0],  # H
    [-0.757, 0.586, 0.0]  # H
])
water = Atoms('OH2', positions=positions, cell=[10, 10, 10], pbc=True)

methods = ['direct', 'ewald', 'pme']
results = {}

for method in methods:
    print(f"\n{method.upper()} method:")
    calc = QEqCalculator(method=method, solver='linear', r_cut=5.0)
    water.calc = calc
    energy = water.get_potential_energy()
    charges = calc.charges.copy()
    
    results[method] = {'energy': energy, 'charges': charges}
    
    print(f"  Energy: {energy:.6f} eV")
    print(f"  Charges: O={charges[0]:.6f}, H1={charges[1]:.6f}, H2={charges[2]:.6f}")

print("\n" + "-"*70)
print("CHARGE COMPARISON (Water):")
print("-"*70)
for i, (m1, m2) in enumerate([('direct', 'ewald'), ('direct', 'pme'), ('ewald', 'pme')]):
    q1 = results[m1]['charges']
    q2 = results[m2]['charges']
    diff = np.max(np.abs(q1 - q2))
    print(f"{m1.upper()} vs {m2.upper()}: max charge diff = {diff:.6f}")

# Now test on large system
print("\n\n" + "="*70)
print("LARGE SYSTEM TEST (3070 atoms)")
print("="*70)

atoms = read('POSCAR')
results_large = {}

for method in methods:
    print(f"\n{method.upper()} method:")
    calc = QEqCalculator(method=method, solver='linear', r_cut=6.0)
    atoms.calc = calc
    energy = atoms.get_potential_energy()
    charges = calc.charges.copy()
    
    results_large[method] = {'energy': energy, 'charges': charges}
    
    print(f"  Energy: {energy:.6f} eV")
    print(f"  Charge range: [{charges.min():.6f}, {charges.max():.6f}]")
    print(f"  Total charge: {charges.sum():.10f}")

print("\n" + "-"*70)
print("CHARGE COMPARISON (Large System):")
print("-"*70)
for m1, m2 in [('direct', 'ewald'), ('direct', 'pme'), ('ewald', 'pme')]:
    q1 = results_large[m1]['charges']
    q2 = results_large[m2]['charges']
    diff = np.max(np.abs(q1 - q2))
    mean_diff = np.mean(np.abs(q1 - q2))
    print(f"{m1.upper()} vs {m2.upper()}: max diff = {diff:.6f}, mean diff = {mean_diff:.6f}")

print("\n" + "-"*70)
print("ENERGY COMPARISON (Large System):")
print("-"*70)
for m1, m2 in [('direct', 'ewald'), ('direct', 'pme'), ('ewald', 'pme')]:
    e1 = results_large[m1]['energy']
    e2 = results_large[m2]['energy']
    diff = abs(e1 - e2)
    percent = 100 * diff / max(abs(e1), abs(e2))
    print(f"{m1.upper()} vs {m2.upper()}: {diff:.2f} eV ({percent:.2f}%)")

print("\n" + "="*70)
print("ANALYSIS:")
print("="*70)
print("""
The charges SHOULD be similar across methods because:
1. All methods solve the same QEq equation: (η + J)q = χ
2. Only the J (Coulomb) matrix differs between methods
3. The equilibrium charges are determined by χ and η primarily

If charges differ significantly, there may be an issue with:
- Matrix construction (diagonal or off-diagonal terms)
- Self-energy treatment
- Screening functions
""")

