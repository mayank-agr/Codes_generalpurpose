

def test_load_xml_forcefield():
    pass

def test_typification_from_templates():
    pass

def test_build_jax_potential():
    pass

