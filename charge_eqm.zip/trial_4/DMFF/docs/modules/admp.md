# ADMP

Automatic Differentiable Multipolar Polarizable (ADMP) force field calculator.

[Introduction](../admp/readme.md)
