# Lisense

The project DMFF is licensed under [GNU LGPLv3.0](https://github.com/deepmodeling/DMFF/blob/master/LICENSE).