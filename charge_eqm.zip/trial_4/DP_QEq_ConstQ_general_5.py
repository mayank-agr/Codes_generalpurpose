#!/bin/env python3
"""
QEq Calculator - ASE Calculator for Charge Equilibration

This module provides an ASE Calculator implementation for calculating atomic charges,
energy, and forces using the charge equilibration (QEq) method with either PME or 
direct Coulomb electrostatics.

Usage Example:
--------------
    from ase.io import read
    from DP_QEq_ConstQ_general import QEqCalculator
    
    # Load structure
    atoms = read('structure.xyz')
    
    # Create calculator with PME method (default)
    calc = QEqCalculator(total_charge=0.0, rcut=6.0, method='pme')
    # Or use direct Coulomb method
    # calc = QEqCalculator(total_charge=0.0, rcut=6.0, method='direct')
    
    atoms.calc = calc
    
    # Calculate properties
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    charges = calc.get_charges()
    
    print(f"Energy: {energy} eV")
    print(f"Total charge: {charges.sum()}")
"""

import sys
import os
# Use extracted DMFF modules (lightweight, no full DMFF package needed)
sys.path.insert(0, os.path.dirname(__file__))

from dmff_extracted.utils import pair_buffer_scales, regularize_pairs
import jax.numpy as jnp
from dmff_extracted.admp.recip import generate_pme_recip, Ck_1
from dmff_extracted.admp.pme import energy_pme
from jax import jit, grad, jacfwd, jacrev, value_and_grad
from jax.scipy.special import erfc
import jaxopt
import numpy as np
import jax
from typing import TYPE_CHECKING, Optional, List, Dict
import ase.io as IO
from ase.calculators.calculator import Calculator, all_changes
from ase import Atoms
from ase.data import atomic_numbers, covalent_radii
import time
import json

initial_charge_guess_list = []
initial_charge_guess_list.append(np.zeros(3070))


def load_qeq_params(params_file: str) -> Dict:
    """Load QEq parameters (chi and eta) from JSON file
    
    Parameters
    ----------
    params_file : str
        Path to JSON file containing QEq parameters
        
    Returns
    -------
    params : dict
        Dictionary with element symbols as keys and dict of chi/eta as values
    """
    with open(params_file, 'r') as f:
        params = json.load(f)
    return params


def determine_chi(
        box,
        positions: np.ndarray,
        symbols: list
):
    
    chi_0 = np.array([element_defaults[tmp]['chi'] for tmp in symbols])
    return chi_0


class NeighborListJAX:
    def __init__(self, box, rcut, cov_map, padding=True, max_shape=0):
        self.box = box
        self.rcut = rcut
        self.capacity_multiplier = None
        self.padding = padding
        self.cov_map = cov_map
        self.max_shape = max_shape
    
    def _do_cov_map(self, pairs):
        nbond = self.cov_map[pairs[:, 0], pairs[:, 1]]
        pairs = jnp.concatenate([pairs, nbond[:, None]], axis=1)
        return pairs
    
    def _compute_neighbor_list(self, coords, box, rcut):
        """Efficiently compute neighbor list using fully vectorized operations"""
        natoms = coords.shape[0]
        box_inv = np.linalg.inv(box)
        
        # Create all pair indices where i < j using meshgrid
        i_indices, j_indices = np.triu_indices(natoms, k=1)
        
        # Get positions for all pairs at once
        pos_i = coords[i_indices]
        pos_j = coords[j_indices]
        
        # Compute all displacement vectors
        dpos = pos_i - pos_j
        
        # Apply periodic boundary conditions (vectorized)
        dpos_scaled = dpos @ box_inv.T
        dpos_scaled -= np.floor(dpos_scaled + 0.5)
        dpos_pbc = dpos_scaled @ box.T
        
        # Compute all distances at once
        distances = np.linalg.norm(dpos_pbc, axis=1)
        
        # Find pairs within cutoff
        mask = distances < rcut
        
        # Build neighbor list
        nlist = np.column_stack([i_indices[mask], j_indices[mask]]).astype(np.int32)
        
        return nlist

    def allocate(self, coords, box=None):
        self._positions = coords  # cache it
        current_box = box if box is not None else self.box
        
        # Compute neighbor list
        nlist = self._compute_neighbor_list(coords, current_box, self.rcut)
        
        if self.capacity_multiplier is None:
            if self.max_shape == 0:
                self.capacity_multiplier = int(nlist.shape[0] * 1.3)
            else:
                self.capacity_multiplier = self.max_shape
        
        if not self.padding:
            self._pairs = self._do_cov_map(nlist)
            return self._pairs

        if self.max_shape == 0:
            self.capacity_multiplier = max(self.capacity_multiplier, nlist.shape[0])
        else:
            self.capacity_multiplier = self.max_shape

        padding_width = self.capacity_multiplier - nlist.shape[0]
        if padding_width == 0:
            self._pairs = self._do_cov_map(nlist)
            return self._pairs
        elif padding_width > 0:
            padding = np.ones((self.capacity_multiplier - nlist.shape[0], 2), dtype=np.int32) * coords.shape[0]
            nlist = np.vstack((nlist, padding))
            self._pairs = self._do_cov_map(nlist)
            return self._pairs
        else:
            raise ValueError("padding width < 0")

    def update(self, positions, box=None):
        self.allocate(positions, box)

    @property
    def pairs(self):
        return self._pairs

    @property
    def scaled_pairs(self):
        return self._pairs

    @property
    def positions(self):
        return self._positions

@jit
def ds_pairs(positions, box, pairs):
    pos1 = positions[pairs[:,0].astype(int)]
    pos2 = positions[pairs[:,1].astype(int)]
    box_inv = jnp.linalg.inv(box)
    dpos = pos1 - pos2
    dpos = dpos.dot(box_inv)
    dpos -= jnp.floor(dpos+0.5)
    dr = dpos.dot(box)
    ds = jnp.linalg.norm(dr,axis=1)
    return ds

def typemap_list_to_symbols(atom_numbs: list, atom_names: list):
    atomic_symbols = []
    idx = 0
    for numb in atom_numbs:
        atomic_symbols.extend((atom_names[idx], )*numb)
        idx += 1
    return atomic_symbols

def generate_get_energy(kappa, K1, K2, K3):
    pme_recip_fn = generate_pme_recip(
        Ck_fn=Ck_1,
        kappa=kappa / 10,
        gamma=False,
        pme_order=6,
        K1=K1,
        K2=K2,
        K3=K3,
        lmax=0,
    )
    def get_energy_kernel(positions, box, pairs, charges, mscales):
        atomCharges = charges
        atomChargesT = jnp.reshape(atomCharges, (-1, 1))
        return energy_pme(
            positions * 10,
            box * 10,
            pairs,
            atomChargesT,
            None,
            None,
            None,
            mscales,
            None,
            None,
            None,
            pme_recip_fn,
            kappa / 10,
            K1,
            K2,
            K3,
            0,
            False,
        )
    def get_energy(positions, box, pairs, charges, mscales):
        return get_energy_kernel(positions, box, pairs, charges, mscales)
    return get_energy

@jit
def get_Energy_Direct_Coulomb(charges, positions, box, pairs):
    """Calculate direct Coulomb energy with minimum image convention"""
    ds = ds_pairs(positions, box, pairs)
    buffer_scales = pair_buffer_scales(pairs)
    # Direct Coulomb interaction: qi * qj / r
    e_coulomb = charges[pairs[:,0]] * charges[pairs[:,1]] * 1389.35455846 / ds * buffer_scales
    return jnp.sum(e_coulomb)

@jit 
def get_Energy_Qeq_PME(charges, positions, box, pairs, alpha, chi, hardness):
    """QEq energy calculation using PME method"""
    @jit 
    def get_Energy_PME():
        pme = generate_get_energy(4.3804348, 45, 123, 22)
        e = pme(positions/10, box/10, pairs, charges, mscales=jnp.array([1., 1., 1., 1., 1., 1.]))
        return e
    @jit 
    def get_Energy_Correction():
        ds = ds_pairs(positions, box, pairs)
        buffer_scales = pair_buffer_scales(pairs)
        e_corr_pair = charges[pairs[:,0]] * charges[pairs[:,1]] * erfc(ds / (jnp.sqrt(2) * jnp.sqrt(alpha[pairs[:,0]]**2 + alpha[pairs[:,1]]**2))) * 1389.35455846 / ds  * buffer_scales
        e_corr_self = charges * charges * 1389.35455846 /(2*jnp.sqrt(jnp.pi) * alpha)
        return  -jnp.sum(e_corr_pair) + jnp.sum(e_corr_self)
    @jit
    def get_Energy_Onsite():
        E_tf =  (chi * charges + 0.5 * hardness * charges *charges) * 96.4869
        #E_tf = 0.5 * hardness * charges *charges * 96.4869
        return jnp.sum(E_tf)
    @jit 
    def get_dipole_correction():
        V = jnp.linalg.det(box)
        pre_corr = 2 * jnp.pi / V * 1389.35455846
        Mz = jnp.sum(charges * positions[:, 1])
        e_corr = pre_corr * Mz**2       
        return jnp.sum(e_corr)

    return (get_Energy_PME() + get_Energy_Correction() + get_Energy_Onsite() + get_dipole_correction()) / 96.4869

@jit 
def get_Energy_Qeq_Direct(charges, positions, box, pairs, alpha, chi, hardness):
    """QEq energy calculation using direct Coulomb method"""
    @jit
    def get_Energy_Coulomb():
        ds = ds_pairs(positions, box, pairs)
        buffer_scales = pair_buffer_scales(pairs)
        # Direct Coulomb with Gaussian screening correction
        e_coulomb_pair = charges[pairs[:,0]] * charges[pairs[:,1]] * erfc(ds / (jnp.sqrt(2) * jnp.sqrt(alpha[pairs[:,0]]**2 + alpha[pairs[:,1]]**2))) * 1389.35455846 / ds * buffer_scales
        e_coulomb_self = charges * charges * 1389.35455846 /(2*jnp.sqrt(jnp.pi) * alpha)
        return jnp.sum(e_coulomb_pair) + jnp.sum(e_coulomb_self)
    @jit
    def get_Energy_Onsite():
        E_tf =  (chi * charges + 0.5 * hardness * charges *charges) * 96.4869
        return jnp.sum(E_tf)

    return (get_Energy_Coulomb() + get_Energy_Onsite()) / 96.4869

@jit
def get_Energy_Qeq_Ewald(charges, positions, box, pairs, alpha, chi, hardness, ewald_alpha=0.3):
    """QEq energy calculation using Ewald summation method
    
    Parameters
    ----------
    ewald_alpha : float
        Ewald splitting parameter (in 1/Angstrom). Default is 0.3
    """
    @jit
    def get_Energy_RealSpace():
        """Real-space part of Ewald summation"""
        ds = ds_pairs(positions, box, pairs)
        buffer_scales = pair_buffer_scales(pairs)
        # Real-space Ewald: erfc(alpha*r) / r with Gaussian screening
        screening = erfc(ds / (jnp.sqrt(2) * jnp.sqrt(alpha[pairs[:,0]]**2 + alpha[pairs[:,1]]**2)))
        ewald_screening = erfc(ewald_alpha * ds)
        e_real_pair = charges[pairs[:,0]] * charges[pairs[:,1]] * screening * ewald_screening * 1389.35455846 / ds * buffer_scales
        # Self-energy correction for Gaussian screening
        e_self_gaussian = charges * charges * 1389.35455846 /(2*jnp.sqrt(jnp.pi) * alpha)
        return jnp.sum(e_real_pair) + jnp.sum(e_self_gaussian)
    
    @jit
    def get_Energy_ReciprocalSpace():
        """Reciprocal-space part of Ewald summation"""
        V = jnp.linalg.det(box)
        # Simple reciprocal space implementation
        # For a full implementation, would need to sum over k-vectors
        # Here we use a dipole correction as approximation
        pre_factor = 2 * jnp.pi / V * 1389.35455846
        dipole_moment = jnp.sum(charges[:, None] * positions, axis=0)
        e_recip = pre_factor * jnp.sum(dipole_moment**2)
        return e_recip
    
    @jit
    def get_Energy_SelfCorrection():
        """Self-energy correction for Ewald summation"""
        e_self = -ewald_alpha / jnp.sqrt(jnp.pi) * jnp.sum(charges**2) * 1389.35455846
        return e_self
    
    @jit
    def get_Energy_Onsite():
        E_tf = (chi * charges + 0.5 * hardness * charges * charges) * 96.4869
        return jnp.sum(E_tf)
    
    return (get_Energy_RealSpace() + get_Energy_ReciprocalSpace() + 
            get_Energy_SelfCorrection() + get_Energy_Onsite()) / 96.4869

@jit 
def get_Energy_Qeq_2(charges, positions, box, pairs, alpha, chi, hardness):
    """Legacy function - defaults to PME method for backward compatibility"""
    return get_Energy_Qeq_PME(charges, positions, box, pairs, alpha, chi, hardness)

def fn_value_and_proj_grad(func, constraint_matrix, has_aux=False):
    def value_and_proj_grad(*arg, **kwargs):
        value, grad = jax.value_and_grad(func, has_aux=has_aux)(*arg, **kwargs)
        # n * 1
        a = jnp.matmul(constraint_matrix, grad.reshape(-1, 1))
        # n * 1
        b = jnp.sum(constraint_matrix * constraint_matrix, axis=1, keepdims=True)
        # 1 * N
        delta_grad = jnp.matmul((a / b).T, constraint_matrix)
        # N
        proj_grad = grad - delta_grad.reshape(-1)
        return value, proj_grad
    return value_and_proj_grad

def build_coulomb_matrix_direct(positions, box, pairs, alpha):
    """Build Coulomb matrix for Direct method"""
    natoms = positions.shape[0]
    J = jnp.zeros((natoms, natoms))
    ds = ds_pairs(positions, box, pairs)
    
    # Direct Coulomb with Gaussian screening
    interaction = erfc(ds / (jnp.sqrt(2) * jnp.sqrt(alpha[pairs[:,0]]**2 + alpha[pairs[:,1]]**2))) * 1389.35455846 / ds
    
    # Fill symmetric matrix
    i_indices = pairs[:, 0]
    j_indices = pairs[:, 1]
    J = J.at[i_indices, j_indices].set(interaction)
    J = J.at[j_indices, i_indices].set(interaction)
    
    return J

def build_coulomb_matrix_pme(positions, box, pairs, alpha):
    """Build Coulomb matrix for PME method (approximated as screened Coulomb)"""
    # For matrix method with PME, we approximate using screened Coulomb
    # The full PME would require grid operations which don't fit matrix form
    return build_coulomb_matrix_direct(positions, box, pairs, alpha)

def build_coulomb_matrix_ewald(positions, box, pairs, alpha, ewald_alpha=0.3):
    """Build Coulomb matrix for Ewald method"""
    natoms = positions.shape[0]
    J = jnp.zeros((natoms, natoms))
    ds = ds_pairs(positions, box, pairs)
    
    # Ewald with both Gaussian and Ewald screening
    screening = erfc(ds / (jnp.sqrt(2) * jnp.sqrt(alpha[pairs[:,0]]**2 + alpha[pairs[:,1]]**2)))
    ewald_screening = erfc(ewald_alpha * ds)
    interaction = screening * ewald_screening * 1389.35455846 / ds
    
    # Fill symmetric matrix
    i_indices = pairs[:, 0]
    j_indices = pairs[:, 1]
    J = J.at[i_indices, j_indices].set(interaction)
    J = J.at[j_indices, i_indices].set(interaction)
    
    return J

def solve_q_matrix_direct(positions, box, pairs, alpha, chi, hardness, total_charge=0.0):
    """Solve for equilibrium charges using direct matrix inversion (Direct method)"""
    natoms = positions.shape[0]
    J_coulomb = build_coulomb_matrix_direct(positions, box, pairs, alpha)
    
    # Add hardness to diagonal: J_ii = η_i + self-interaction
    # Self-interaction from Gaussian: q²/(2√π α)
    self_interaction = 1389.35455846 / (jnp.sqrt(jnp.pi) * alpha)
    J = J_coulomb + jnp.diag(hardness * 96.4869 + self_interaction)
    
    # Build augmented matrix for charge constraint
    # [J  1] 
    # [1ᵀ 0]
    augmented = jnp.zeros((natoms + 1, natoms + 1))
    augmented = augmented.at[:natoms, :natoms].set(J)
    augmented = augmented.at[:natoms, natoms].set(1.0)
    augmented = augmented.at[natoms, :natoms].set(1.0)
    
    # Build right-hand side: [-χ, Q_tot]
    rhs = jnp.zeros(natoms + 1)
    rhs = rhs.at[:natoms].set(-chi * 96.4869)
    rhs = rhs.at[natoms].set(total_charge)
    
    # Solve linear system
    solution = jnp.linalg.solve(augmented, rhs)
    
    # Extract charges (first N elements)
    charges = solution[:natoms]
    
    return charges

def solve_q_matrix_pme(positions, box, pairs, alpha, chi, hardness, total_charge=0.0):
    """Solve for equilibrium charges using direct matrix inversion (PME method)
    
    WARNING: The matrix-based solver approximates PME with real-space screened Coulomb only.
    It does NOT include the reciprocal space (k-space) contributions from PME.
    For accurate PME results, use solver='pg' instead.
    This approximation is only provided for comparison purposes.
    """
    # PME matrix approximation uses same as direct
    return solve_q_matrix_direct(positions, box, pairs, alpha, chi, hardness, total_charge)

def solve_q_matrix_ewald(positions, box, pairs, alpha, chi, hardness, total_charge=0.0):
    """Solve for equilibrium charges using direct matrix inversion (Ewald method)
    
    WARNING: The matrix-based solver uses an incomplete representation of Ewald summation.
    It includes Ewald screening but may not fully capture the convergence acceleration.
    For accurate Ewald results, use solver='pg' instead.
    This approximation is only provided for comparison purposes.
    """
    natoms = positions.shape[0]
    J_coulomb = build_coulomb_matrix_ewald(positions, box, pairs, alpha)
    
    # Add hardness to diagonal: J_ii = η_i + self-interaction
    # Self-interaction from Gaussian: q²/(2√π α)
    self_interaction = 1389.35455846 / (jnp.sqrt(jnp.pi) * alpha)
    J = J_coulomb + jnp.diag(hardness * 96.4869 + self_interaction)
    
    # Build augmented matrix for charge constraint
    # [J  1] 
    # [1ᵀ 0]
    augmented = jnp.zeros((natoms + 1, natoms + 1))
    augmented = augmented.at[:natoms, :natoms].set(J)
    augmented = augmented.at[:natoms, natoms].set(1.0)
    augmented = augmented.at[natoms, :natoms].set(1.0)
    
    # Build right-hand side: [-χ, Q_tot]
    rhs = jnp.zeros(natoms + 1)
    rhs = rhs.at[:natoms].set(-chi * 96.4869)
    rhs = rhs.at[natoms].set(total_charge)
    
    # Solve linear system
    solution = jnp.linalg.solve(augmented, rhs)
    
    # Extract charges (first N elements)
    charges = solution[:natoms]
    
    return charges

def solve_q_pg(charges, positions, box, pairs, alpha, chi, hardness, total_charge=0.0, method='pme'):
    """Solve for equilibrium charges using projected gradient method (L-BFGS)
    
    Parameters
    ----------
    method : str
        Electrostatics method: 'pme' (default), 'direct', or 'ewald'
    """
    # Select energy function based on method
    if method.lower() == 'direct':
        energy_func = get_Energy_Qeq_Direct
    elif method.lower() == 'ewald':
        energy_func = get_Energy_Qeq_Ewald
    else:  # default to PME
        energy_func = get_Energy_Qeq_PME
    
    # Adjust initial charges to satisfy total charge constraint
    charge_deficit = total_charge - jnp.sum(charges)
    charges = charges + charge_deficit / len(charges)
    
    func = fn_value_and_proj_grad(energy_func, jnp.ones_like(charges).reshape(1, -1))
    solver = jaxopt.LBFGS(
        fun=func,
        value_and_grad=True,
        tol=1e-2,
        )
    res = solver.run(charges, positions, box, pairs, alpha, chi, hardness)
    x_opt = res.params
    
    # Re-apply total charge constraint after optimization
    charge_deficit = total_charge - jnp.sum(x_opt)
    x_opt = x_opt + charge_deficit / len(x_opt)
    
    return x_opt

def get_force(charges, positions, box, pairs, alpha, chi, hardness, method='pme'):
    """Calculate energy and forces
    
    Parameters
    ----------
    method : str
        Electrostatics method: 'pme' (default), 'direct', or 'ewald'
    """
    # Select energy function based on method
    if method.lower() == 'direct':
        energy_func = get_Energy_Qeq_Direct
    elif method.lower() == 'ewald':
        energy_func = get_Energy_Qeq_Ewald
    else:  # default to PME
        energy_func = get_Energy_Qeq_PME
    
    energy_force_fn = jit(value_and_grad(energy_func, argnums=(1)))
    energy, force = energy_force_fn(charges, positions, box, pairs, alpha, chi, hardness)
    return energy, -force

def get_qeq_energy_and_force_pg(charges, positions, box, pairs, alpha, chi, hardness, total_charge=0.0, method='pme', solver='pg'):
    """Calculate QEq energy, forces, and charges
    
    Parameters
    ----------
    method : str
        Electrostatics method: 'pme' (default), 'direct', or 'ewald'
    solver : str
        Solver type: 'pg' for projected gradient (L-BFGS, default) or 'matrix' for direct matrix inversion
    """
    method_lower = method.lower()
    solver_lower = solver.lower()
    
    # Select solver based on method and solver type
    if solver_lower == 'matrix':
        if method_lower == 'direct':
            q = solve_q_matrix_direct(positions, box, pairs, alpha, chi, hardness, total_charge)
        elif method_lower == 'ewald':
            q = solve_q_matrix_ewald(positions, box, pairs, alpha, chi, hardness, total_charge)
        else:  # pme
            q = solve_q_matrix_pme(positions, box, pairs, alpha, chi, hardness, total_charge)
    else:  # 'pg' solver
        q = solve_q_pg(charges, positions, box, pairs, alpha, chi, hardness, total_charge, method)
    
    energy, force = get_force(q, positions, box, pairs, alpha, chi, hardness, method)
    return energy, force, q

def get_neighbor_list(box, rc, positions, natoms, padding=True, max_shape=0):
    nbl = NeighborListJAX(box, rc, jnp.zeros([natoms, natoms], dtype=jnp.int32), padding=padding, max_shape=max_shape)
    nbl.allocate(positions, box)
    pairs = nbl.pairs
    pairs = pairs.at[:, :2].set(regularize_pairs(pairs[:, :2]))
    return pairs



if TYPE_CHECKING:
    from ase import Atoms

__all__ = ["QEqCalculator"]

# Default QEq parameters for common elements
# These are used as fallback when no parameter file is provided
element_defaults = {
    'H': {'chi': 5.3200, 'eta': 7.4366},
    'C': {'chi': 5.8678, 'eta': 7.0000},
    'N': {'chi': 6.9000, 'eta': 11.7600},
    'O': {'chi': 8.5000, 'eta': 8.9989},
    'Li': {'chi': -3.0000, 'eta': 10.0241},
    'P': {'chi': 1.8000, 'eta': 7.0946},
    'F': {'chi': 9.0000, 'eta': 8.0000},
}


def cell_to_box(a, b, c, alpha, beta, gamma):
    alpha = alpha / 180 * np.pi
    beta  = beta  / 180 * np.pi
    gamma = gamma / 180 * np.pi

    box = np.zeros((3,3), dtype=np.double) 
    box[0, 0] = a
    box[0, 1] = 0
    box[0, 2] = 0
    box[1, 0] = b * np.cos(gamma)
    box[1, 1] = b * np.sin(gamma)
    box[1, 2] = 0
    box[2, 0] = c * np.cos(beta)
    box[2, 1] = c * (np.cos(alpha)-np.cos(beta)*np.cos(gamma)) / np.sin(gamma)
    box[2, 2] = c * np.sqrt(1 - np.cos(beta)**2 - ((np.cos(alpha)-np.cos(beta)*np.cos(gamma))/np.sin(gamma))**2)
    return box


class QEqCalculator(Calculator):
    """
    ASE Calculator for charge equilibration (QEq) method.
    
    Calculates atomic charges, energy, and forces using the charge equilibration method
    with PME, direct Coulomb, or Ewald summation electrostatics and Gaussian charge distributions.
    
    Parameters
    ----------
    total_charge : float, optional
        Total charge of the system (default: 0.0 for neutral systems)
    rcut : float, optional
        Cutoff distance for neighbor list in Angstroms (default: 6.0)
    max_pairs : int, optional
        Maximum number of neighbor pairs for padding (default: 200000)
    initial_charges : np.ndarray, optional
        Initial guess for charges. If None, random charges are used.
    method : str, optional
        Electrostatics method: 'pme' for Particle Mesh Ewald (default), 
        'direct' for direct Coulomb, or 'ewald' for Ewald summation
    solver : str, optional
        Solver type: 'pg' for projected gradient/L-BFGS (default, iterative),
        or 'matrix' for direct matrix inversion (exact, single-step)
    params_file : str, optional
        Path to JSON file containing QEq parameters (chi and eta values). 
        If None, uses hardcoded default values (default: 'qeq_params.json')
    kappa : float, optional
        Ewald parameter (default: 4.3804348, only used for PME method)
    K1, K2, K3 : int, optional
        PME grid dimensions (default: 45, 123, 22, only used for PME method)
    ewald_alpha : float, optional
        Ewald splitting parameter in 1/Angstrom (default: 0.3, only used for Ewald method)
    **kwargs
        Additional arguments passed to Calculator
    """
    
    implemented_properties = ['energy', 'forces', 'charges']
    
    def __init__(self, 
                 total_charge: float = 0.0,
                 rcut: float = 6.0,
                 max_pairs: int = 200000,
                 initial_charges: Optional[np.ndarray] = None,
                 method: str = 'pme',
                 solver: str = 'pg',
                 params_file: Optional[str] = 'qeq_params.json',
                 kappa: float = 4.3804348,
                 K1: int = 45,
                 K2: int = 123,
                 K3: int = 22,
                 ewald_alpha: float = 0.3,
                 **kwargs):
        
        Calculator.__init__(self, **kwargs)
        
        self.total_charge = total_charge
        self.rcut = rcut
        self.max_pairs = max_pairs
        self.initial_charges = initial_charges
        self.method = method.lower()
        self.solver = solver.lower()
        self.params_file = params_file
        self.kappa = kappa
        self.K1 = K1
        self.K2 = K2
        self.K3 = K3
        self.ewald_alpha = ewald_alpha
        self.last_charges = None
        
        # Load QEq parameters from file if provided
        if self.params_file is not None and os.path.exists(self.params_file):
            self.qeq_params = load_qeq_params(self.params_file)
        else:
            self.qeq_params = None
    
    def calculate(self, 
                  atoms: Optional[Atoms] = None,
                  properties: List[str] = ['energy', 'forces', 'charges'],
                  system_changes: List[str] = all_changes):
        """
        Calculate properties for the given atoms object.
        
        Parameters
        ----------
        atoms : Atoms
            ASE Atoms object
        properties : list of str
            List of properties to calculate
        system_changes : list of str
            List of changes since last calculation
        """
        
        if atoms is not None:
            self.atoms = atoms.copy()
        
        Calculator.calculate(self, atoms, properties, system_changes)
        
        # Get atomic positions and cell
        positions = jnp.array(self.atoms.get_positions())
        cell = self.atoms.cell.cellpar()
        box = jnp.array(cell_to_box(cell[0], cell[1], cell[2], cell[3], cell[4], cell[5]))
        symbols = self.atoms.get_chemical_symbols()
        natoms = len(self.atoms)
        
        # Initialize charges
        if self.initial_charges is not None:
            charges = jnp.array(self.initial_charges)
        elif self.last_charges is not None and len(self.last_charges) == natoms:
            charges = self.last_charges
        else:
            charges = jnp.array(np.random.random(natoms))
        
        # Get element-specific parameters
        if self.qeq_params is not None:
            # Load from JSON file
            chi = jnp.array([self.qeq_params[tmp]['chi'] for tmp in symbols])
            hardness = jnp.array([self.qeq_params[tmp]['eta'] for tmp in symbols])
        else:
            # Use element_defaults dictionary
            chi = jnp.array([element_defaults[tmp]['chi'] for tmp in symbols])
            hardness = jnp.array([element_defaults[tmp]['eta'] for tmp in symbols])
        # Get covalent radii from ASE data (in Angstroms)
        alpha = jnp.array([covalent_radii[atomic_numbers[tmp]] for tmp in symbols])
        
        # Build neighbor list
        pairs = get_neighbor_list(box, self.rcut, positions, natoms, 
                                  padding=True, max_shape=self.max_pairs)
        
        # Solve for charges, energy, and forces
        energy, force, charges_opt = get_qeq_energy_and_force_pg(
            charges, positions, box, pairs, alpha, chi, hardness, self.total_charge, self.method, self.solver
        )
        
        # Store results
        self.results['energy'] = float(energy)
        self.results['forces'] = np.array(force).reshape(-1, 3)
        self.results['charges'] = np.array(charges_opt)
        
        # Save charges for next iteration
        self.last_charges = charges_opt
    
    def get_charges(self):
        """
        Get the calculated atomic charges.
        
        Returns
        -------
        charges : np.ndarray
            Atomic charges
        """
        if 'charges' not in self.results:
            raise RuntimeError("Charges have not been calculated yet. Run calculate() first.")
        return self.results['charges']


if __name__ == "__main__":
    # Example usage - comparing PME, Direct, and Ewald methods with different solvers
    print("=" * 70)
    print("QEq Calculator - Comparing Methods and Solvers")
    print("=" * 70)
    
    # Load structure
    # atoms = IO.read('water.xyz')
    atoms = IO.read('POSCAR')
    print(f"\nLoaded structure: {len(atoms)} atoms")
    print(f"Chemical formula: {atoms.get_chemical_formula()}")
    
    # Run calculations for all three methods and both solvers
    methods = ['pme', 'direct', 'ewald']
    solvers = ['pg', 'matrix']
    results = {}
    
    for method in methods:
        results[method] = {}
        for solver in solvers:
            key = f"{method}_{solver}"
            print(f"\n{'=' * 70}")
            print(f"Running {method.upper()} method with {solver.upper()} solver")
            print('=' * 70)
            
            # Create calculator with total charge = 0 (neutral system)
            calc = QEqCalculator(total_charge=0.0, rcut=6.0, max_pairs=200000, 
                                method=method, solver=solver)
            
            # Attach calculator to atoms
            atoms.calc = calc
            
            # Calculate properties
            print("\nCalculating charges, energy, and forces...")
            time1 = time.process_time()
            
            energy = atoms.get_potential_energy()
            forces = atoms.get_forces()
            charges = calc.get_charges()
            
            time2 = time.process_time()
            calc_time = time2 - time1
            
            # Store results
            results[method][solver] = {
                'energy': energy,
                'forces': forces,
                'charges': charges,
                'time': calc_time
            }
            
            # Print results
            print(f"\nResults ({method.upper()} method, {solver.upper()} solver):")
            print(f"  Energy: {energy:.6f} eV")
            print(f"  Total charge: {np.sum(charges):.6f} (Target: {calc.total_charge:.6f})")
            print(f"  Calculation time: {calc_time:.3f} s")
            print(f"\nCharge statistics:")
            print(f"  Min charge: {np.min(charges):.6f}")
            print(f"  Max charge: {np.max(charges):.6f}")
            print(f"  Mean charge: {np.mean(charges):.6f}")
            print(f"\nForce statistics:")
            print(f"  Max force: {np.max(np.linalg.norm(forces, axis=1)):.6f} eV/Å")
            print(f"  Mean force: {np.mean(np.linalg.norm(forces, axis=1)):.6f} eV/Å")
            
            # Save results
            np.savetxt(f'energy_qeq_{method}_{solver}.txt', [energy])
            np.savetxt(f'charges_qeq_{method}_{solver}.txt', charges)
            np.savetxt(f'forces_qeq_{method}_{solver}.txt', forces)
            
            print(f"\nResults saved to:")
            print(f"  - energy_qeq_{method}_{solver}.txt")
            print(f"  - charges_qeq_{method}_{solver}.txt")
            print(f"  - forces_qeq_{method}_{solver}.txt")
    
    # Summary comparison
    print(f"\n{'=' * 70}")
    print("COMPARISON SUMMARY")
    print('=' * 70)
    print(f"\n{'Method-Solver':<20} {'Energy (eV)':<15} {'Time (s)':<12} {'Max Force (eV/Å)':<15}")
    print('-' * 70)
    for method in methods:
        for solver in solvers:
            r = results[method][solver]
            max_force = np.max(np.linalg.norm(r['forces'], axis=1))
            label = f"{method.upper()}-{solver.upper()}"
            print(f"{label:<20} {r['energy']:<15.6f} {r['time']:<12.3f} {max_force:<15.6f}")
    
    # Compare solvers for each method
    print(f"\n{'=' * 70}")
    print("SOLVER COMPARISON (for each method)")
    print('=' * 70)
    for method in methods:
        print(f"\n{method.upper()} method:")
        pg_result = results[method]['pg']
        mat_result = results[method]['matrix']
        
        energy_diff = abs(pg_result['energy'] - mat_result['energy'])
        charge_diff = np.max(np.abs(pg_result['charges'] - mat_result['charges']))
        force_diff = np.max(np.linalg.norm(pg_result['forces'] - mat_result['forces'], axis=1))
        
        print(f"  Energy difference (PG - Matrix):  {energy_diff:.6e} eV")
        print(f"  Max charge difference:             {charge_diff:.6e}")
        print(f"  Max force difference:              {force_diff:.6e} eV/Å")
        print(f"  Speedup (PG time / Matrix time):   {pg_result['time'] / mat_result['time']:.2f}x")
    
    print("\n" + "=" * 70)
