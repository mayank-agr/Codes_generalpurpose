from jax import config as jax_config

# Configuration constants
PRECISION = 'double'  # Options: 'single', 'double'
DO_JIT = True
DEBUG = False


def update_jax_precision(precision: str):
    """
    Updates JAX precision mode.
    
    Parameters:
        precision (str): 'double' to enable float64, anything else for float32
    """
    jax_config.update("jax_enable_x64", precision == 'double')


# Set precision before importing jax.numpy or similar modules
update_jax_precision(PRECISION)

__all__ = ['PRECISION', 'DO_JIT', 'DEBUG', 'update_jax_precision']
