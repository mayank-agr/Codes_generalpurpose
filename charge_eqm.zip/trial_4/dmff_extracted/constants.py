import numpy as np

DIELECTRIC = 1389.35455846
SQRT_PI = np.sqrt(np.pi)