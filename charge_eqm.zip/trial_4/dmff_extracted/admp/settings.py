# DEFAULT THRESHOLDS
POL_CONV = 1.0 # gradient convergence thresh for induced dipoles
MAX_N_POL = 30  # maximum number of cyles for optimizing induced dipole
