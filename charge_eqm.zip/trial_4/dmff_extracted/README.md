# DMFF Extracted Module

This directory contains the necessary DMFF functions extracted from the full DMFF package to make the QEq Calculator standalone.

## Contents

- `utils.py` - Utility functions (pair_buffer_scales, regularize_pairs)
- `settings.py` - DMFF settings
- `admp/` - ADMP module containing PME and reciprocal space calculations
  - `recip.py` - Reciprocal space functions (generate_pme_recip, Ck_1)
  - `pme.py` - PME energy calculation (energy_pme)
- `common/` - Common constants and utilities

## Purpose

These files allow the QEq Calculator to run without requiring the full DMFF package installation. Only the PME-related functions needed for electrostatics calculations are included.

## Source

Extracted from DMFF (Differentiable Molecular Force Field)
Original repository: https://github.com/deepmodeling/DMFF
