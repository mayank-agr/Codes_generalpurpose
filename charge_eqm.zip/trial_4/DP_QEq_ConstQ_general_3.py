#!/bin/env python3
"""
QEq Calculator - ASE Calculator for Charge Equilibration

This module provides an ASE Calculator implementation for calculating atomic charges,
energy, and forces using the charge equilibration (QEq) method with either PME or 
direct Coulomb electrostatics.

Usage Example:
--------------
    from ase.io import read
    from DP_QEq_ConstQ_general import QEqCalculator
    
    # Load structure
    atoms = read('structure.xyz')
    
    # Create calculator with PME method (default)
    calc = QEqCalculator(total_charge=0.0, rcut=6.0, method='pme')
    # Or use direct Coulomb method
    # calc = QEqCalculator(total_charge=0.0, rcut=6.0, method='direct')
    
    atoms.calc = calc
    
    # Calculate properties
    energy = atoms.get_potential_energy()
    forces = atoms.get_forces()
    charges = calc.get_charges()
    
    print(f"Energy: {energy} eV")
    print(f"Total charge: {charges.sum()}")
"""

import sys
import os
# Use extracted DMFF modules (lightweight, no full DMFF package needed)
sys.path.insert(0, os.path.dirname(__file__))

from dmff_extracted.utils import pair_buffer_scales, regularize_pairs
import jax.numpy as jnp
from dmff_extracted.admp.recip import generate_pme_recip, Ck_1
from dmff_extracted.admp.pme import energy_pme
from jax import jit, grad, jacfwd, jacrev, value_and_grad
from jax.scipy.special import erfc
import jaxopt
import numpy as np
import jax
from typing import TYPE_CHECKING, Optional, List, Dict
import ase.io as IO
from ase.calculators.calculator import Calculator, all_changes
from ase import Atoms
import time

initial_charge_guess_list = []
initial_charge_guess_list.append(np.zeros(3070))


def determine_chi(
        box,
        positions: np.ndarray,
        symbols: list
):
    
    chi_0 = np.array([name2chi[tmp] for tmp in symbols])
    return chi_0


class NeighborListJAX:
    def __init__(self, box, rcut, cov_map, padding=True, max_shape=0):
        self.box = box
        self.rcut = rcut
        self.capacity_multiplier = None
        self.padding = padding
        self.cov_map = cov_map
        self.max_shape = max_shape
    
    def _do_cov_map(self, pairs):
        nbond = self.cov_map[pairs[:, 0], pairs[:, 1]]
        pairs = jnp.concatenate([pairs, nbond[:, None]], axis=1)
        return pairs
    
    def _compute_neighbor_list(self, coords, box, rcut):
        """Efficiently compute neighbor list using fully vectorized operations"""
        natoms = coords.shape[0]
        box_inv = np.linalg.inv(box)
        
        # Create all pair indices where i < j using meshgrid
        i_indices, j_indices = np.triu_indices(natoms, k=1)
        
        # Get positions for all pairs at once
        pos_i = coords[i_indices]
        pos_j = coords[j_indices]
        
        # Compute all displacement vectors
        dpos = pos_i - pos_j
        
        # Apply periodic boundary conditions (vectorized)
        dpos_scaled = dpos @ box_inv.T
        dpos_scaled -= np.floor(dpos_scaled + 0.5)
        dpos_pbc = dpos_scaled @ box.T
        
        # Compute all distances at once
        distances = np.linalg.norm(dpos_pbc, axis=1)
        
        # Find pairs within cutoff
        mask = distances < rcut
        
        # Build neighbor list
        nlist = np.column_stack([i_indices[mask], j_indices[mask]]).astype(np.int32)
        
        return nlist

    def allocate(self, coords, box=None):
        self._positions = coords  # cache it
        current_box = box if box is not None else self.box
        
        # Compute neighbor list
        nlist = self._compute_neighbor_list(coords, current_box, self.rcut)
        
        if self.capacity_multiplier is None:
            if self.max_shape == 0:
                self.capacity_multiplier = int(nlist.shape[0] * 1.3)
            else:
                self.capacity_multiplier = self.max_shape
        
        if not self.padding:
            self._pairs = self._do_cov_map(nlist)
            return self._pairs

        if self.max_shape == 0:
            self.capacity_multiplier = max(self.capacity_multiplier, nlist.shape[0])
        else:
            self.capacity_multiplier = self.max_shape

        padding_width = self.capacity_multiplier - nlist.shape[0]
        if padding_width == 0:
            self._pairs = self._do_cov_map(nlist)
            return self._pairs
        elif padding_width > 0:
            padding = np.ones((self.capacity_multiplier - nlist.shape[0], 2), dtype=np.int32) * coords.shape[0]
            nlist = np.vstack((nlist, padding))
            self._pairs = self._do_cov_map(nlist)
            return self._pairs
        else:
            raise ValueError("padding width < 0")

    def update(self, positions, box=None):
        self.allocate(positions, box)

    @property
    def pairs(self):
        return self._pairs

    @property
    def scaled_pairs(self):
        return self._pairs

    @property
    def positions(self):
        return self._positions

@jit
def ds_pairs(positions, box, pairs):
    pos1 = positions[pairs[:,0].astype(int)]
    pos2 = positions[pairs[:,1].astype(int)]
    box_inv = jnp.linalg.inv(box)
    dpos = pos1 - pos2
    dpos = dpos.dot(box_inv)
    dpos -= jnp.floor(dpos+0.5)
    dr = dpos.dot(box)
    ds = jnp.linalg.norm(dr,axis=1)
    return ds

def typemap_list_to_symbols(atom_numbs: list, atom_names: list):
    atomic_symbols = []
    idx = 0
    for numb in atom_numbs:
        atomic_symbols.extend((atom_names[idx], )*numb)
        idx += 1
    return atomic_symbols

def generate_get_energy(kappa, K1, K2, K3):
    pme_recip_fn = generate_pme_recip(
        Ck_fn=Ck_1,
        kappa=kappa / 10,
        gamma=False,
        pme_order=6,
        K1=K1,
        K2=K2,
        K3=K3,
        lmax=0,
    )
    def get_energy_kernel(positions, box, pairs, charges, mscales):
        atomCharges = charges
        atomChargesT = jnp.reshape(atomCharges, (-1, 1))
        return energy_pme(
            positions * 10,
            box * 10,
            pairs,
            atomChargesT,
            None,
            None,
            None,
            mscales,
            None,
            None,
            None,
            pme_recip_fn,
            kappa / 10,
            K1,
            K2,
            K3,
            0,
            False,
        )
    def get_energy(positions, box, pairs, charges, mscales):
        return get_energy_kernel(positions, box, pairs, charges, mscales)
    return get_energy

@jit
def get_Energy_Direct_Coulomb(charges, positions, box, pairs):
    """Calculate direct Coulomb energy with minimum image convention"""
    ds = ds_pairs(positions, box, pairs)
    buffer_scales = pair_buffer_scales(pairs)
    # Direct Coulomb interaction: qi * qj / r
    e_coulomb = charges[pairs[:,0]] * charges[pairs[:,1]] * 1389.35455846 / ds * buffer_scales
    return jnp.sum(e_coulomb)

@jit 
def get_Energy_Qeq_PME(charges, positions, box, pairs, alpha, chi, hardness):
    """QEq energy calculation using PME method"""
    @jit 
    def get_Energy_PME():
        pme = generate_get_energy(4.3804348, 45, 123, 22)
        e = pme(positions/10, box/10, pairs, charges, mscales=jnp.array([1., 1., 1., 1., 1., 1.]))
        return e
    @jit 
    def get_Energy_Correction():
        ds = ds_pairs(positions, box, pairs)
        buffer_scales = pair_buffer_scales(pairs)
        e_corr_pair = charges[pairs[:,0]] * charges[pairs[:,1]] * erfc(ds / (jnp.sqrt(2) * jnp.sqrt(alpha[pairs[:,0]]**2 + alpha[pairs[:,1]]**2))) * 1389.35455846 / ds  * buffer_scales
        e_corr_self = charges * charges * 1389.35455846 /(2*jnp.sqrt(jnp.pi) * alpha)
        return  -jnp.sum(e_corr_pair) + jnp.sum(e_corr_self)
    @jit
    def get_Energy_Onsite():
        E_tf =  (chi * charges + 0.5 * hardness * charges *charges) * 96.4869
        #E_tf = 0.5 * hardness * charges *charges * 96.4869
        return jnp.sum(E_tf)
    @jit 
    def get_dipole_correction():
        V = jnp.linalg.det(box)
        pre_corr = 2 * jnp.pi / V * 1389.35455846
        Mz = jnp.sum(charges * positions[:, 1])
        e_corr = pre_corr * Mz**2       
        return jnp.sum(e_corr)

    return (get_Energy_PME() + get_Energy_Correction() + get_Energy_Onsite() + get_dipole_correction()) / 96.4869

@jit 
def get_Energy_Qeq_Direct(charges, positions, box, pairs, alpha, chi, hardness):
    """QEq energy calculation using direct Coulomb method"""
    @jit
    def get_Energy_Coulomb():
        ds = ds_pairs(positions, box, pairs)
        buffer_scales = pair_buffer_scales(pairs)
        # Direct Coulomb with Gaussian screening correction
        e_coulomb_pair = charges[pairs[:,0]] * charges[pairs[:,1]] * erfc(ds / (jnp.sqrt(2) * jnp.sqrt(alpha[pairs[:,0]]**2 + alpha[pairs[:,1]]**2))) * 1389.35455846 / ds * buffer_scales
        e_coulomb_self = charges * charges * 1389.35455846 /(2*jnp.sqrt(jnp.pi) * alpha)
        return jnp.sum(e_coulomb_pair) + jnp.sum(e_coulomb_self)
    @jit
    def get_Energy_Onsite():
        E_tf =  (chi * charges + 0.5 * hardness * charges *charges) * 96.4869
        return jnp.sum(E_tf)

    return (get_Energy_Coulomb() + get_Energy_Onsite()) / 96.4869

@jit 
def get_Energy_Qeq_2(charges, positions, box, pairs, alpha, chi, hardness):
    """Legacy function - defaults to PME method for backward compatibility"""
    return get_Energy_Qeq_PME(charges, positions, box, pairs, alpha, chi, hardness)

def fn_value_and_proj_grad(func, constraint_matrix, has_aux=False):
    def value_and_proj_grad(*arg, **kwargs):
        value, grad = jax.value_and_grad(func, has_aux=has_aux)(*arg, **kwargs)
        # n * 1
        a = jnp.matmul(constraint_matrix, grad.reshape(-1, 1))
        # n * 1
        b = jnp.sum(constraint_matrix * constraint_matrix, axis=1, keepdims=True)
        # 1 * N
        delta_grad = jnp.matmul((a / b).T, constraint_matrix)
        # N
        proj_grad = grad - delta_grad.reshape(-1)
        return value, proj_grad
    return value_and_proj_grad

def solve_q_pg(charges, positions, box, pairs, alpha, chi, hardness, total_charge=0.0, method='pme'):
    """Solve for equilibrium charges using projected gradient method
    
    Parameters
    ----------
    method : str
        Electrostatics method: 'pme' (default) or 'direct'
    """
    # Select energy function based on method
    if method.lower() == 'direct':
        energy_func = get_Energy_Qeq_Direct
    else:  # default to PME
        energy_func = get_Energy_Qeq_PME
    
    # Adjust initial charges to satisfy total charge constraint
    charge_deficit = total_charge - jnp.sum(charges)
    charges = charges + charge_deficit / len(charges)
    
    func = fn_value_and_proj_grad(energy_func, jnp.ones_like(charges).reshape(1, -1))
    solver = jaxopt.LBFGS(
        fun=func,
        value_and_grad=True,
        tol=1e-2,
        )
    res = solver.run(charges, positions, box, pairs, alpha, chi, hardness)
    x_opt = res.params
    
    # Re-apply total charge constraint after optimization
    charge_deficit = total_charge - jnp.sum(x_opt)
    x_opt = x_opt + charge_deficit / len(x_opt)
    
    return x_opt

def get_force(charges, positions, box, pairs, alpha, chi, hardness, method='pme'):
    """Calculate energy and forces
    
    Parameters
    ----------
    method : str
        Electrostatics method: 'pme' (default) or 'direct'
    """
    # Select energy function based on method
    if method.lower() == 'direct':
        energy_func = get_Energy_Qeq_Direct
    else:  # default to PME
        energy_func = get_Energy_Qeq_PME
    
    energy_force_fn = jit(value_and_grad(energy_func, argnums=(1)))
    energy, force = energy_force_fn(charges, positions, box, pairs, alpha, chi, hardness)
    return energy, -force

def get_qeq_energy_and_force_pg(charges, positions, box, pairs, alpha, chi, hardness, total_charge=0.0, method='pme'):
    """Calculate QEq energy, forces, and charges
    
    Parameters
    ----------
    method : str
        Electrostatics method: 'pme' (default) or 'direct'
    """
    q = solve_q_pg(charges, positions, box, pairs, alpha, chi, hardness, total_charge, method)
    energy, force = get_force(q, positions, box, pairs, alpha, chi, hardness, method)
    return energy, force, q

def get_neighbor_list(box, rc, positions, natoms, padding=True, max_shape=0):
    nbl = NeighborListJAX(box, rc, jnp.zeros([natoms, natoms], dtype=jnp.int32), padding=padding, max_shape=max_shape)
    nbl.allocate(positions, box)
    pairs = nbl.pairs
    pairs = pairs.at[:, :2].set(regularize_pairs(pairs[:, :2]))
    return pairs



if TYPE_CHECKING:
    from ase import Atoms

__all__ = ["QEqCalculator"]

name2eta = {
    "Li":10.0241,
    "C":7.0000,
    "H":7.4366,
    "O":8.9989,
    "P":7.0946,
    "F":8.0000,
}

name2chi = {
    "Li":-3.0000,
    "C":5.8678,
    "H":5.3200,
    "O":8.5000,
    "P":1.8000,
    "F":9.0000,
}

name2index = {
    "H": 1,
    "He": 2,
    "Li": 3,
    "Be": 4,
    "B": 5,
    "C": 6,
    "N": 7,
    "O": 8,
    "F": 9,
    "Ne": 10,
    "Na": 11,
    "Mg": 12,
    "Al": 13,
    "Si": 14,
    "P": 15,
    "S": 16,
    "Cl": 17,
    "Ar": 18,
    "K": 19,
    "Ca": 20,
    "Sc": 21,
    "Ti": 22,
    "V": 23,
    "Cr": 24,
    "Mn": 25,
    "Fe": 26,
    "Co": 27,
    "Ni": 28,
    "Cu": 29,
    "Zn": 30,
    "Ga": 31,
    "Ge": 32,
    "As": 33,
    "Se": 34,
    "Br": 35,
    "Kr": 36,
    "Rb": 37,
    "Sr": 38,
    "Y": 39,
    "Zr": 40,
    "Nb": 41,
    "Mo": 42,
    "Tc": 43,
    "Ru": 44,
    "Rh": 45,
    "Pd": 46,
    "Ag": 47,
    "Cd": 48,
    "In": 49,
    "Sn": 50,
    "Sb": 51,
    "Te": 52,
    "I": 53,
    "Xe": 54,
    "Cs": 55,
    "Ba": 56,
    "La": 57,
    "Ce": 58,
    "Pr": 59,
    "Nd": 60,
    "Pm": 61,
    "Sm": 62,
    "Eu": 63,
    "Gd": 64,
    "Tb": 65,
    "Dy": 66,
    "Ho": 67,
    "Er": 68,
    "Tm": 69,
    "Yb": 70,
    "Lu": 71,
    "Hf": 72,
    "Ta": 73,
    "W": 74,
    "Re": 75,
    "Os": 76,
    "Ir": 77,
    "Pt": 78,
    "Au": 79,
    "Hg": 80,
    "Tl": 81,
    "Pb": 82,
    "Bi": 83,
    "Po": 84,
    "At": 85,
    "Rn": 86,
    "Fr": 87,
    "Ra": 88,
    "Ac": 89,
    "Th": 90,
    "Pa": 91,
    "U": 92,
    "Np": 93,
    "Pu": 94,
    "Am": 95,
    "Cm": 96,
    "Bk": 97,
    "Cf": 98,
    "Es": 99,
    "Fm": 100,
    "Md": 101,
    "No": 102,
    "Lr": 103,
    "Rf": 104,
    "Db": 105,
    "Sg": 106,
    "Bh": 107,
    "Hs": 108,
    "Mt": 109,
    "Ds": 110,
    "Rg": 111,
    "Cn": 112,
    "Uut": 113,
    "Uuq": 114,
    "Uup": 115,
    "Uuh": 116,
    "Uus": 117,
    "Uuo": 118,
}

R_Covalence = (
    2.0,  # ghost?
    0.31,  #H
    0.28,  #He
    1.28,  #Li
    0.96,  #Be
    0.84,  #B
    0.76,  #C
    0.71,  #N
    0.66,  #O
    0.57,  #F
    0.58,  #Ne
    1.66,  #Na
    1.41,  #Mg
    1.21,  #Al
    1.11,  #Si
    1.07,  #P
    1.05,  #S
    1.02,  #Cl
    1.06,  #Ar
    2.03,  #K
    1.76,  #Ca
    1.70,  #Sc
    1.60,  #Ti
    1.53,  #V
    1.39,  #Cr
    1.61,  #Mn
    1.52,  #Fe
    1.50,  #Co
    1.24,  #Ni
    1.32,  #Cu
    1.22,  #Zn
    1.22,  #Ga
    1.20,  #Ge
    1.19,  #As
    1.20,  #Se
    1.20,  #Br
    1.16,  #Kr
    2.20,  #Rb
    1.95,  #Sr
    1.90,  #Y
    1.75,  #Zr
    1.64,  #Nb
    1.54,  #Mo
    1.47,  #Tc
    1.46,  #Ru
    1.42,  #Rh
    1.39,  #Pd
    1.45,  #Ag
    1.44,  #Cd
    1.42,  #In
    1.39,  #Sn
    1.39,  #Sb
    1.38,  #Te
    1.39,  #I
    1.40,  #Xe
    2.44,  #Cs
    2.15,  #Ba
    2.07,  #La
    2.04,  #Ce
    2.03,  #Pr
    2.01,  #Nd
    1.99,  #Pm
    1.98,  #Sm
    1.98,  #Eu
    1.96,  #Gd
    1.94,  #Tb
    1.92,  #Dy
    1.92,  #Ho
    1.89,  #Er
    1.90,  #Tm
    1.87,  #Yb
    1.87,  #Lu
    1.75,  #Hf
    1.70,  #Ta
    1.62,  #W
    1.51,  #Re
    1.44,  #Os
    1.41,  #Ir
    1.36,  #Pt
    1.36,  #Au
    1.32,  #Hg
    1.45,  #Tl
    1.46,  #Pb
    1.48,  #Bi
    1.40,  #Po
    1.50,  #At
    1.50,  #Rn
    2.60,  #Fr
    2.21,  #Ra
    2.15,  #Ac
    2.06,  #Th
    2.00,  #Pa
    1.96,  #U
    1.90,  #Np
    1.87,  #Pu
    1.80,  #Am
    1.69  #Cm
)


def cell_to_box(a, b, c, alpha, beta, gamma):
    alpha = alpha / 180 * np.pi
    beta  = beta  / 180 * np.pi
    gamma = gamma / 180 * np.pi

    box = np.zeros((3,3), dtype=np.double) 
    box[0, 0] = a
    box[0, 1] = 0
    box[0, 2] = 0
    box[1, 0] = b * np.cos(gamma)
    box[1, 1] = b * np.sin(gamma)
    box[1, 2] = 0
    box[2, 0] = c * np.cos(beta)
    box[2, 1] = c * (np.cos(alpha)-np.cos(beta)*np.cos(gamma)) / np.sin(gamma)
    box[2, 2] = c * np.sqrt(1 - np.cos(beta)**2 - ((np.cos(alpha)-np.cos(beta)*np.cos(gamma))/np.sin(gamma))**2)
    return box


class QEqCalculator(Calculator):
    """
    ASE Calculator for charge equilibration (QEq) method.
    
    Calculates atomic charges, energy, and forces using the charge equilibration method
    with either PME or direct Coulomb electrostatics and Gaussian charge distributions.
    
    Parameters
    ----------
    total_charge : float, optional
        Total charge of the system (default: 0.0 for neutral systems)
    rcut : float, optional
        Cutoff distance for neighbor list in Angstroms (default: 6.0)
    max_pairs : int, optional
        Maximum number of neighbor pairs for padding (default: 200000)
    initial_charges : np.ndarray, optional
        Initial guess for charges. If None, random charges are used.
    method : str, optional
        Electrostatics method: 'pme' for Particle Mesh Ewald (default) or 'direct' for direct Coulomb
    kappa : float, optional
        Ewald parameter (default: 4.3804348, only used for PME method)
    K1, K2, K3 : int, optional
        PME grid dimensions (default: 45, 123, 22, only used for PME method)
    **kwargs
        Additional arguments passed to Calculator
    """
    
    implemented_properties = ['energy', 'forces', 'charges']
    
    def __init__(self, 
                 total_charge: float = 0.0,
                 rcut: float = 6.0,
                 max_pairs: int = 200000,
                 initial_charges: Optional[np.ndarray] = None,
                 method: str = 'pme',
                 kappa: float = 4.3804348,
                 K1: int = 45,
                 K2: int = 123,
                 K3: int = 22,
                 **kwargs):
        
        Calculator.__init__(self, **kwargs)
        
        self.total_charge = total_charge
        self.rcut = rcut
        self.max_pairs = max_pairs
        self.initial_charges = initial_charges
        self.method = method.lower()
        self.kappa = kappa
        self.K1 = K1
        self.K2 = K2
        self.K3 = K3
        self.last_charges = None
    
    def calculate(self, 
                  atoms: Optional[Atoms] = None,
                  properties: List[str] = ['energy', 'forces', 'charges'],
                  system_changes: List[str] = all_changes):
        """
        Calculate properties for the given atoms object.
        
        Parameters
        ----------
        atoms : Atoms
            ASE Atoms object
        properties : list of str
            List of properties to calculate
        system_changes : list of str
            List of changes since last calculation
        """
        
        if atoms is not None:
            self.atoms = atoms.copy()
        
        Calculator.calculate(self, atoms, properties, system_changes)
        
        # Get atomic positions and cell
        positions = jnp.array(self.atoms.get_positions())
        cell = self.atoms.cell.cellpar()
        box = jnp.array(cell_to_box(cell[0], cell[1], cell[2], cell[3], cell[4], cell[5]))
        symbols = self.atoms.get_chemical_symbols()
        natoms = len(self.atoms)
        
        # Initialize charges
        if self.initial_charges is not None:
            charges = jnp.array(self.initial_charges)
        elif self.last_charges is not None and len(self.last_charges) == natoms:
            charges = self.last_charges
        else:
            charges = jnp.array(np.random.random(natoms))
        
        # Get element-specific parameters
        chi = jnp.array([name2chi[tmp] for tmp in symbols])
        hardness = jnp.array([name2eta[tmp] for tmp in symbols])
        alpha = jnp.array([R_Covalence[name2index[tmp]] for tmp in symbols])
        
        # Build neighbor list
        pairs = get_neighbor_list(box, self.rcut, positions, natoms, 
                                  padding=True, max_shape=self.max_pairs)
        
        # Solve for charges, energy, and forces
        energy, force, charges_opt = get_qeq_energy_and_force_pg(
            charges, positions, box, pairs, alpha, chi, hardness, self.total_charge, self.method
        )
        
        # Store results
        self.results['energy'] = float(energy)
        self.results['forces'] = np.array(force).reshape(-1, 3)
        self.results['charges'] = np.array(charges_opt)
        
        # Save charges for next iteration
        self.last_charges = charges_opt
    
    def get_charges(self):
        """
        Get the calculated atomic charges.
        
        Returns
        -------
        charges : np.ndarray
            Atomic charges
        """
        if 'charges' not in self.results:
            raise RuntimeError("Charges have not been calculated yet. Run calculate() first.")
        return self.results['charges']


if __name__ == "__main__":
    # Example usage - comparing PME and Direct Coulomb methods
    print("=" * 60)
    print("QEq Calculator - Comparing PME and Direct Methods")
    print("=" * 60)
    
    # Load structure
    atoms = IO.read('POSCAR')
    print(f"\nLoaded structure: {len(atoms)} atoms")
    print(f"Chemical formula: {atoms.get_chemical_formula()}")
    
    # Run calculations for both methods
    methods = ['pme', 'direct']
    results = {}
    
    for method in methods:
        print(f"\n{'=' * 60}")
        print(f"Running {method.upper()} method")
        print('=' * 60)
        
        # Create calculator with total charge = 0 (neutral system)
        calc = QEqCalculator(total_charge=0.0, rcut=6.0, max_pairs=200000, method=method)
        
        # Attach calculator to atoms
        atoms.calc = calc
        
        # Calculate properties
        print("\nCalculating charges, energy, and forces...")
        time1 = time.process_time()
        
        energy = atoms.get_potential_energy()
        forces = atoms.get_forces()
        charges = calc.get_charges()
        
        time2 = time.process_time()
        calc_time = time2 - time1
        
        # Store results
        results[method] = {
            'energy': energy,
            'forces': forces,
            'charges': charges,
            'time': calc_time
        }
        
        # Print results
        print(f"\nResults ({method.upper()} method):")
        print(f"  Energy: {energy:.6f} eV")
        print(f"  Total charge: {np.sum(charges):.6f} (Target: {calc.total_charge:.6f})")
        print(f"  Calculation time: {calc_time:.3f} s")
        print(f"\nCharge statistics:")
        print(f"  Min charge: {np.min(charges):.6f}")
        print(f"  Max charge: {np.max(charges):.6f}")
        print(f"  Mean charge: {np.mean(charges):.6f}")
        print(f"\nForce statistics:")
        print(f"  Max force: {np.max(np.linalg.norm(forces, axis=1)):.6f} eV/Å")
        print(f"  Mean force: {np.mean(np.linalg.norm(forces, axis=1)):.6f} eV/Å")
        
        # Save results
        np.savetxt(f'energy_qeq_{method}.txt', [energy])
        np.savetxt(f'charges_qeq_{method}.txt', charges)
        np.savetxt(f'forces_qeq_{method}.txt', forces)
        
        print(f"\nResults saved to:")
        print(f"  - energy_qeq_{method}.txt")
        print(f"  - charges_qeq_{method}.txt")
        print(f"  - forces_qeq_{method}.txt")
    
    # Summary comparison
    print(f"\n{'=' * 60}")
    print("COMPARISON SUMMARY")
    print('=' * 60)
    print(f"\n{'Method':<10} {'Energy (eV)':<15} {'Time (s)':<12} {'Max Force (eV/Å)':<15}")
    print('-' * 60)
    for method in methods:
        r = results[method]
        max_force = np.max(np.linalg.norm(r['forces'], axis=1))
        print(f"{method.upper():<10} {r['energy']:<15.6f} {r['time']:<12.3f} {max_force:<15.6f}")
    
    energy_diff = results['pme']['energy'] - results['direct']['energy']
    print(f"\nEnergy difference (PME - Direct): {energy_diff:.6f} eV")
    print("\n" + "=" * 60)
