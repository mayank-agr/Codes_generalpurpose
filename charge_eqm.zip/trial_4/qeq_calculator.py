#!/bin/env python3
"""
QEq Calculator Class for Charge Equilibration
Predicts atomic partial charges, energies, and forces using the QEq method with PME electrostatics
"""

# Use extracted DMFF functions instead of full library
from dmff_extracted import pair_buffer_scales, regularize_pairs
from dmff_extracted import generate_pme_recip, Ck_1, energy_pme

import jax.numpy as jnp
from jax import jit, value_and_grad
from jax.scipy.special import erfc
import jaxopt
import numpy as np
import jax

import ase.io as IO


# =============================================================================
# Neighbor List Function (converted from class)
# =============================================================================

def build_neighbor_list(positions, box, rcut, cov_map=None, padding=True, max_shape=0):
    """
    Build neighbor list using cell list algorithm for O(N) performance
    
    Parameters:
    -----------
    positions : array (N, 3)
        Atomic positions in Angstroms
    box : array (3, 3)
        Box vectors in Angstroms (rows are box vectors)
    rcut : float
        Cutoff distance in Angstroms
    cov_map : array (N, N), optional
        Covalent bonding map (topological distances)
    padding : bool
        Whether to pad the neighbor list to fixed size
    max_shape : int
        Maximum size for padded neighbor list (0 = auto)
    
    Returns:
    --------
    pairs : array (Npairs, 3)
        Pair indices and bonding topology: [i, j, nbond]
    """
    # Convert JAX arrays to NumPy for efficient indexing
    if hasattr(positions, 'block_until_ready'):
        coords_np = np.array(positions)
    else:
        coords_np = positions
    
    if hasattr(box, 'block_until_ready'):
        box_np = np.array(box)
    else:
        box_np = box
    
    natoms = coords_np.shape[0]
    rcut_sq = rcut * rcut
    
    # Build cell list for efficient neighbor search
    box_lengths = np.array([np.linalg.norm(box_np[i]) for i in range(3)])
    n_cells = np.maximum(1, (box_lengths / rcut).astype(int))
    
    # Compute inverse box for fractional coordinates
    box_inv = np.linalg.inv(box_np)
    
    # Convert to fractional coordinates and assign to cells
    frac_coords = coords_np.dot(box_inv)
    frac_coords = frac_coords - np.floor(frac_coords)  # Wrap to [0, 1)
    
    cell_indices = (frac_coords * n_cells).astype(int)
    cell_indices = np.clip(cell_indices, 0, n_cells - 1)
    
    # Build cell list dictionary
    cell_list = {}
    for i, cell_idx in enumerate(cell_indices):
        cell_key = tuple(cell_idx)
        if cell_key not in cell_list:
            cell_list[cell_key] = []
        cell_list[cell_key].append(i)
    
    def get_neighbor_cells(cell_idx, n_cells):
        """Get indices of neighboring cells including self"""
        neighbors = []
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                for dz in [-1, 0, 1]:
                    neighbor = (
                        (cell_idx[0] + dx) % n_cells[0],
                        (cell_idx[1] + dy) % n_cells[1],
                        (cell_idx[2] + dz) % n_cells[2]
                    )
                    neighbors.append(neighbor)
        return neighbors
    
    def minimum_image_distance_sq(dr, box_inv):
        """Apply minimum image convention and return squared distance"""
        frac = dr.dot(box_inv)
        frac = frac - np.round(frac)
        dr_mic = frac.dot(box_np)
        return np.sum(dr_mic * dr_mic)
    
    pairs_list = []
    
    # Iterate over cells instead of all atom pairs
    for cell_key, atoms_in_cell in cell_list.items():
        neighbor_cells = get_neighbor_cells(cell_key, n_cells)
        
        # Check pairs within same cell
        for idx_i, i in enumerate(atoms_in_cell):
            for j in atoms_in_cell[idx_i + 1:]:
                dr = coords_np[j] - coords_np[i]
                dist_sq = minimum_image_distance_sq(dr, box_inv)
                if dist_sq < rcut_sq:
                    pairs_list.append([i, j])
        
        # Check pairs with neighboring cells
        for neighbor_cell in neighbor_cells:
            if neighbor_cell == cell_key:
                continue  # Already handled above
            if neighbor_cell not in cell_list:
                continue
                
            for i in atoms_in_cell:
                for j in cell_list[neighbor_cell]:
                    if i < j:  # Avoid double counting
                        dr = coords_np[j] - coords_np[i]
                        dist_sq = minimum_image_distance_sq(dr, box_inv)
                        if dist_sq < rcut_sq:
                            pairs_list.append([i, j])
    
    if len(pairs_list) > 0:
        nlist = np.array(pairs_list, dtype=np.int32)
    else:
        nlist = np.zeros((0, 2), dtype=np.int32)
    
    # Add covalent map information
    if cov_map is None:
        cov_map = np.zeros([natoms, natoms], dtype=np.int32)
    
    nbond = cov_map[nlist[:, 0], nlist[:, 1]]
    pairs = jnp.concatenate([jnp.array(nlist), nbond[:, None]], axis=1)
    
    # Apply padding if requested
    if padding:
        if max_shape == 0:
            capacity = int(nlist.shape[0] * 1.3)
        else:
            capacity = max_shape
        
        if pairs.shape[0] < capacity:
            padding_width = capacity - pairs.shape[0]
            padding_array = jnp.ones((padding_width, 2), dtype=jnp.int32) * natoms
            padding_array = jnp.concatenate([padding_array, jnp.zeros((padding_width, 1), dtype=jnp.int32)], axis=1)
            pairs = jnp.vstack((pairs, padding_array))
    
    # Regularize pairs
    pairs = pairs.at[:, :2].set(regularize_pairs(pairs[:, :2]))
    
    return pairs


# =============================================================================
# QEq Calculator Class
# =============================================================================

class QEqCalculator:
    """
    Charge Equilibration (QEq) Calculator using PME electrostatics
    
    This calculator predicts atomic partial charges by minimizing the QEq energy functional,
    which includes PME electrostatics, Gaussian screening, onsite energies, and dipole corrections.
    """
    
    # Element parameters for QEq
    ELEMENT_ETA = {
        "Li": 10.0241, "C": 7.0000, "H": 7.4366, "O": 8.9989, "P": 7.0946, "F": 8.0000,
    }
    
    ELEMENT_CHI = {
        "Li": -3.0000, "C": 5.8678, "H": 5.3200, "O": 8.5000, "P": 1.8000, "F": 9.0000,
    }
    
    ELEMENT_INDEX = {
        "H": 1, "He": 2, "Li": 3, "Be": 4, "B": 5, "C": 6, "N": 7, "O": 8, "F": 9, "Ne": 10,
        "Na": 11, "Mg": 12, "Al": 13, "Si": 14, "P": 15, "S": 16, "Cl": 17, "Ar": 18,
        "K": 19, "Ca": 20, "Sc": 21, "Ti": 22, "V": 23, "Cr": 24, "Mn": 25, "Fe": 26,
        "Co": 27, "Ni": 28, "Cu": 29, "Zn": 30, "Ga": 31, "Ge": 32, "As": 33, "Se": 34,
        "Br": 35, "Kr": 36, "Rb": 37, "Sr": 38, "Y": 39, "Zr": 40, "Nb": 41, "Mo": 42,
        "Tc": 43, "Ru": 44, "Rh": 45, "Pd": 46, "Ag": 47, "Cd": 48, "In": 49, "Sn": 50,
        "Sb": 51, "Te": 52, "I": 53, "Xe": 54, "Cs": 55, "Ba": 56, "La": 57, "Ce": 58,
        "Pr": 59, "Nd": 60, "Pm": 61, "Sm": 62, "Eu": 63, "Gd": 64, "Tb": 65, "Dy": 66,
        "Ho": 67, "Er": 68, "Tm": 69, "Yb": 70, "Lu": 71, "Hf": 72, "Ta": 73, "W": 74,
        "Re": 75, "Os": 76, "Ir": 77, "Pt": 78, "Au": 79, "Hg": 80, "Tl": 81, "Pb": 82,
        "Bi": 83, "Po": 84, "At": 85, "Rn": 86, "Fr": 87, "Ra": 88, "Ac": 89, "Th": 90,
        "Pa": 91, "U": 92, "Np": 93, "Pu": 94, "Am": 95, "Cm": 96, "Bk": 97, "Cf": 98,
        "Es": 99, "Fm": 100, "Md": 101, "No": 102, "Lr": 103, "Rf": 104, "Db": 105,
        "Sg": 106, "Bh": 107, "Hs": 108, "Mt": 109, "Ds": 110, "Rg": 111, "Cn": 112,
        "Uut": 113, "Uuq": 114, "Uup": 115, "Uuh": 116, "Uus": 117, "Uuo": 118,
    }
    
    R_COVALENCE = (
        2.0, 0.31, 0.28, 1.28, 0.96, 0.84, 0.76, 0.71, 0.66, 0.57, 0.58, 1.66, 1.41, 1.21,
        1.11, 1.07, 1.05, 1.02, 1.06, 2.03, 1.76, 1.70, 1.60, 1.53, 1.39, 1.61, 1.52, 1.50,
        1.24, 1.32, 1.22, 1.22, 1.20, 1.19, 1.20, 1.20, 1.16, 2.20, 1.95, 1.90, 1.75, 1.64,
        1.54, 1.47, 1.46, 1.42, 1.39, 1.45, 1.44, 1.42, 1.39, 1.39, 1.38, 1.39, 1.40, 2.44,
        2.15, 2.07, 2.04, 2.03, 2.01, 1.99, 1.98, 1.98, 1.96, 1.94, 1.92, 1.92, 1.89, 1.90,
        1.87, 1.87, 1.75, 1.70, 1.62, 1.51, 1.44, 1.41, 1.36, 1.36, 1.32, 1.45, 1.46, 1.48,
        1.40, 1.50, 1.50, 2.60, 2.21, 2.15, 2.06, 2.00, 1.96, 1.90, 1.87, 1.80, 1.69
    )
    
    def __init__(self, rcut=6.0, kappa=4.3804348, K1=45, K2=123, K3=22, 
                 lbfgs_tol=1e-2, max_neighbors=200000):
        """
        Initialize QEq Calculator
        
        Parameters:
        -----------
        rcut : float
            Neighbor list cutoff in Angstroms (default: 6.0)
        kappa : float
            PME attenuation parameter (default: 4.3804348)
        K1, K2, K3 : int
            PME grid dimensions (default: 45, 123, 22)
        lbfgs_tol : float
            L-BFGS convergence tolerance (default: 1e-2)
        max_neighbors : int
            Maximum neighbor list size (default: 200000)
        """
        self.rcut = rcut
        self.kappa = kappa
        self.K1 = K1
        self.K2 = K2
        self.K3 = K3
        self.lbfgs_tol = lbfgs_tol
        self.max_neighbors = max_neighbors
        
        # Generate PME reciprocal space calculator
        self.pme_recip_fn = generate_pme_recip(
            Ck_fn=Ck_1,
            kappa=kappa / 10,
            gamma=False,
            pme_order=6,
            K1=K1,
            K2=K2,
            K3=K3,
            lmax=0,
        )
        
        # JIT-compiled helper functions
        self._ds_pairs = jit(self._ds_pairs_impl)
        self._get_energy_qeq = jit(self._get_energy_qeq_impl)
        self._solve_q_pg = jit(self._solve_q_pg_impl)
        self._get_force = jit(self._get_force_impl)
    
    @staticmethod
    def _ds_pairs_impl(positions, box, pairs):
        """Calculate pairwise distances with PBC"""
        pos1 = positions[pairs[:, 0].astype(int)]
        pos2 = positions[pairs[:, 1].astype(int)]
        box_inv = jnp.linalg.inv(box)
        dpos = pos1 - pos2
        dpos = dpos.dot(box_inv)
        dpos -= jnp.floor(dpos + 0.5)
        dr = dpos.dot(box)
        ds = jnp.linalg.norm(dr, axis=1)
        return ds
    
    def _get_pme_energy(self, positions, box, pairs, charges):
        """Calculate PME electrostatic energy"""
        atomChargesT = jnp.reshape(charges, (-1, 1))
        return energy_pme(
            positions * 10,  # Convert to nm
            box * 10,
            pairs,
            atomChargesT,
            None, None, None,
            jnp.array([1., 1., 1., 1., 1., 1.]),
            None, None, None,
            self.pme_recip_fn,
            self.kappa / 10,
            self.K1, self.K2, self.K3,
            0,
            False,
        )
    
    def _get_energy_qeq_impl(self, charges, positions, box, pairs, eta, chi, hardness):
        """
        Calculate total QEq energy
        
        Components:
        1. PME electrostatics
        2. Gaussian screening correction
        3. Onsite energy (electronegativity + hardness)
        4. Dipole correction for periodic systems
        """
        # PME energy
        e_pme = self._get_pme_energy(positions / 10, box / 10, pairs, charges)
        
        # Gaussian screening correction
        ds = self._ds_pairs(positions, box, pairs)
        buffer_scales = pair_buffer_scales(pairs)
        e_corr_pair = charges[pairs[:, 0]] * charges[pairs[:, 1]] * \
                      erfc(ds / (jnp.sqrt(2) * jnp.sqrt(eta[pairs[:, 0]]**2 + eta[pairs[:, 1]]**2))) * \
                      1389.35455846 / ds * buffer_scales
        e_corr_self = charges * charges * 1389.35455846 / (2 * jnp.sqrt(jnp.pi) * eta)
        e_correction = -jnp.sum(e_corr_pair) + jnp.sum(e_corr_self)
        
        # Onsite energy
        e_onsite = jnp.sum((chi * charges + 0.5 * hardness * charges * charges) * 96.4869)
        
        # Dipole correction
        V = jnp.linalg.det(box)
        pre_corr = 2 * jnp.pi / V * 1389.35455846
        Mz = jnp.sum(charges * positions[:, 1])
        e_dipole = pre_corr * Mz**2
        
        return (e_pme + e_correction + e_onsite + e_dipole) / 96.4869
    
    def _fn_value_and_proj_grad(self, func, constraint_matrix):
        """Create projected gradient function for charge neutrality constraint"""
        def value_and_proj_grad(*args, **kwargs):
            value, grad = jax.value_and_grad(func)(*args, **kwargs)
            # Project out constraint violation
            a = jnp.matmul(constraint_matrix, grad.reshape(-1, 1))
            b = jnp.sum(constraint_matrix * constraint_matrix, axis=1, keepdims=True)
            delta_grad = jnp.matmul((a / b).T, constraint_matrix)
            proj_grad = grad - delta_grad.reshape(-1)
            return value, proj_grad
        return value_and_proj_grad
    
    def _solve_q_pg_impl(self, charges, positions, box, pairs, eta, chi, hardness):
        """Solve for equilibrium charges using L-BFGS with projected gradient"""
        func = self._fn_value_and_proj_grad(
            self._get_energy_qeq,
            jnp.ones_like(charges).reshape(1, -1)
        )
        solver = jaxopt.LBFGS(
            fun=func,
            value_and_grad=True,
            tol=self.lbfgs_tol,
        )
        res = solver.run(charges, positions, box, pairs, eta, chi, hardness)
        return res.params
    
    def _get_force_impl(self, charges, positions, box, pairs, eta, chi, hardness):
        """Calculate energy and forces"""
        energy, force = value_and_grad(self._get_energy_qeq, argnums=(1))(
            charges, positions, box, pairs, eta, chi, hardness
        )
        return energy, -force
    
    def _get_element_parameters(self, symbols):
        """Get QEq parameters for each atom based on element symbols"""
        chi = jnp.array([self.ELEMENT_CHI.get(s, 0.0) for s in symbols])
        hardness = jnp.array([self.ELEMENT_ETA.get(s, 1.0) for s in symbols])
        eta = jnp.array([self.R_COVALENCE[self.ELEMENT_INDEX.get(s, 0)] for s in symbols])
        return chi, hardness, eta
    
    def calculate(self, positions, box=None, symbols=None, initial_charges=None):
        """
        Calculate QEq charges, energy, and forces
        
        Parameters:
        -----------
        positions : array (N, 3) or ASE Atoms
            Atomic positions in Angstroms (can be ASE Atoms object)
        box : array (3, 3), optional
            Box vectors in Angstroms (rows are box vectors)
            If positions is ASE Atoms, this will be extracted automatically
        symbols : list of str, optional
            Chemical symbols for each atom
            If positions is ASE Atoms, this will be extracted automatically
        initial_charges : array (N,), optional
            Initial guess for charges. If None, uses random values.
        
        Returns:
        --------
        results : dict
            Dictionary containing:
            - 'charges': array (N,) - Equilibrium charges in elementary charge units
            - 'energy': float - Total QEq energy in eV
            - 'forces': array (N, 3) - Atomic forces in eV/Angstrom
        """
        # Handle ASE Atoms input
        if hasattr(positions, 'get_positions'):
            atoms = positions
            positions = jnp.array(atoms.get_positions())
            cell = atoms.cell.cellpar()  # Updated to avoid deprecation warning
            box = jnp.array(self._cell_to_box(*cell))
            symbols = atoms.get_chemical_symbols()
        else:
            if box is None or symbols is None:
                raise ValueError("When passing raw arrays, both 'box' and 'symbols' must be provided")
            positions = jnp.array(positions)
            box = jnp.array(box)
        
        natoms = positions.shape[0]
        
        # Get element parameters
        chi, hardness, eta = self._get_element_parameters(symbols)
        
        # Build neighbor list
        pairs = build_neighbor_list(
            positions, box, self.rcut,
            padding=True, max_shape=self.max_neighbors
        )
        
        # Initial charge guess
        if initial_charges is None:
            initial_charges = jnp.array(np.random.random(natoms))
        else:
            initial_charges = jnp.array(initial_charges)
        
        # Solve for equilibrium charges
        charges = self._solve_q_pg(
            initial_charges, positions, box, pairs, eta, chi, hardness
        )
        
        # Calculate energy and forces
        energy, forces = self._get_force(
            charges, positions, box, pairs, eta, chi, hardness
        )
        
        return {
            'charges': np.array(charges),
            'energy': float(energy),
            'forces': np.array(forces)
        }
    
    @staticmethod
    def _cell_to_box(a, b, c, alpha, beta, gamma):
        """Convert cell parameters to box matrix"""
        alpha = alpha / 180 * np.pi
        beta = beta / 180 * np.pi
        gamma = gamma / 180 * np.pi
        
        box = np.zeros((3, 3), dtype=np.double)
        box[0, 0] = a
        box[0, 1] = 0
        box[0, 2] = 0
        box[1, 0] = b * np.cos(gamma)
        box[1, 1] = b * np.sin(gamma)
        box[1, 2] = 0
        box[2, 0] = c * np.cos(beta)
        box[2, 1] = c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)
        box[2, 2] = c * np.sqrt(1 - np.cos(beta)**2 - 
                                 ((np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma))**2)
        return box


# =============================================================================
# Example Usage
# =============================================================================

if __name__ == "__main__":
    import time
    
    # Initialize calculator
    calc = QEqCalculator(rcut=6.0, max_neighbors=200000)
    
    # Load structure from POSCAR
    atoms = IO.read('POSCAR')
    
    # Load initial charge guess
    initial_charges = np.loadtxt("initial_charge_guess.txt")
    
    # Calculate charges, energy, and forces
    print("Calculating QEq charges...")
    time1 = time.process_time()
    
    results = calc.calculate(atoms, initial_charges=initial_charges)
    
    time2 = time.process_time()
    
    print(f"\nEnergy: {results['energy']:.6f} eV")
    print(f"Total charge: {np.sum(results['charges']):.6f} e")
    print(f"Time: {time2 - time1:.3f} s")
    
    # Save results
    np.savetxt('energy_qeq.txt', [results['energy']])
    np.savetxt('charges_qeq.txt', results['charges'])
    
    print("\nResults saved to energy_qeq.txt and charges_qeq.txt")
